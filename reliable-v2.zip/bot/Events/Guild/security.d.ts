export {};
//# sourceMappingURL=security.d.ts.map