export {};
//# sourceMappingURL=antiInsult.d.ts.map