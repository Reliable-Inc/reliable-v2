export {};
//# sourceMappingURL=antiThreat.d.ts.map