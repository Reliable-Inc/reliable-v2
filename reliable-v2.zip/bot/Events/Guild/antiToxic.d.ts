export {};
//# sourceMappingURL=antiToxic.d.ts.map