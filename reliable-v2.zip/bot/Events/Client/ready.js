"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require('discord.js'), Client = _a.Client, Events = _a.Events, ActivityType = _a.ActivityType;
var Configuration = require('../../config');
var REST = require('@discordjs/rest').REST;
var Routes = require('discord-api-types/v10').Routes;
var mongoose = require('mongoose');
var dotenv = require('dotenv');
var _b = require('syc-logger'), logTaDAsync = _b.logTaDAsync, renderDoubledLinesAsync = _b.renderDoubledLinesAsync;
dotenv.config();
var MongoURL = process.env['MongoDB'];
var chalk = require('chalk');
var clientId = process.env['ClientId'];
var guildId = Configuration["default"].guildId;
module.exports = {
    name: Events.ClientReady,
    once: true,
    /**
     *
     * @param {Client} client
     */
    execute: function (client) {
        var _a, _b, _c, _d, _e, _f;
        return __awaiter(this, void 0, void 0, function () {
            var line, commands, rest, error_1;
            return __generator(this, function (_g) {
                switch (_g.label) {
                    case 0:
                        line = renderDoubledLinesAsync(30);
                        console.log('');
                        console.log(chalk.white.bold('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫') +
                            chalk.blue.bold('Bot Info') +
                            chalk.white.bold('┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
                        console.log(chalk.white("".concat(client.guilds.cache.reduce(function (a, b) { return a + b.memberCount; }, 0) > 1
                            ? 'Users:'
                            : 'User:')), chalk.red("".concat((_b = (_a = client === null || client === void 0 ? void 0 : client.guilds) === null || _a === void 0 ? void 0 : _a.cache) === null || _b === void 0 ? void 0 : _b.reduce(function (a, b) { return a + b.memberCount; }, 0))), chalk.white('||'), chalk.white("".concat(((_d = (_c = client === null || client === void 0 ? void 0 : client.guilds) === null || _c === void 0 ? void 0 : _c.cache) === null || _d === void 0 ? void 0 : _d.size) > 1 ? 'Servers:' : 'Server:')), chalk.red("".concat((_f = (_e = client === null || client === void 0 ? void 0 : client.guilds) === null || _e === void 0 ? void 0 : _e.cache) === null || _f === void 0 ? void 0 : _f.size)));
                        console.log(chalk.white("Prefix:" + chalk.red(' /')), chalk.white('||'), chalk.white("Commands:"), chalk.red("".concat(client.commands.size)));
                        console.log('');
                        console.log(chalk.white.bold('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫') +
                            chalk.blue.bold('Statistics') +
                            chalk.white.bold('┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
                        console.log(chalk.white("Running on Node"), chalk.green(process.version), chalk.white('on'), chalk.green("".concat(process.platform, " ").concat(process.arch)));
                        console.log(chalk.white('Memory:'), chalk.green("".concat((process.memoryUsage().rss / 1024 / 1024).toFixed(2))), chalk.white('MB'));
                        console.log(chalk.white('RSS:'), chalk.green("".concat((process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2))), chalk.white('MB'));
                        console.log('');
                        console.log(chalk.white.bold('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫') +
                            chalk.blue.bold('Client Status') +
                            chalk.white.bold('┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
                        mongoose.set('strictQuery', true);
                        mongoose
                            .connect(MongoURL, {
                            useNewUrlParser: true,
                            useUnifiedTopology: true
                        })
                            .then(function () {
                            console.log(chalk.cyan('[ INFORMATION ]') +
                                chalk.white.bold(' | ') +
                                chalk.blue("".concat(new Date().toLocaleDateString())) +
                                chalk.white.bold(' | ') +
                                chalk.cyan('Mongo DB Connection') +
                                chalk.white(': ') +
                                chalk.greenBright("Connected"));
                        });
                        console.log(chalk.cyan('[ INFORMATION ]') +
                            chalk.white.bold(' | ') +
                            chalk.blue("".concat(new Date().toLocaleDateString())) +
                            chalk.white.bold(' | ') +
                            chalk.cyan('Mongo DB Connection') +
                            chalk.white(': ') +
                            chalk.greenBright("Disconnected"));
                        console.log(chalk.cyan('[ INFORMATION ]') +
                            chalk.white.bold(' | ') +
                            chalk.blue("".concat(new Date().toLocaleDateString())) +
                            chalk.white.bold(' | ') +
                            chalk.cyan('Logged in as') +
                            chalk.white(': ') +
                            chalk.greenBright("".concat(client.user.tag)));
                        commands = client.commands.map(function (_a) {
                            var data = _a.data;
                            return data === null || data === void 0 ? void 0 : data.toJSON();
                        });
                        rest = new REST({ version: '10' }).setToken(process === null || process === void 0 ? void 0 : process.env['Token']);
                        _g.label = 1;
                    case 1:
                        _g.trys.push([1, 3, , 4]);
                        console.log(chalk.cyan('[ INFORMATION ]') +
                            chalk.white.bold(' | ') +
                            chalk.blue("".concat(new Date().toLocaleDateString())) +
                            chalk.white.bold(' | ') +
                            chalk.cyan('Application Commands (/)') +
                            chalk.white(': ') +
                            chalk.greenBright("Refresing"));
                        //mamay dekhi akhane akam kortese ;-;
                        return [4 /*yield*/, rest.put(Routes.applicationCommands(clientId), {
                                body: commands
                            })];
                    case 2:
                        //mamay dekhi akhane akam kortese ;-;
                        _g.sent();
                        console.log(chalk.cyan('[ INFORMATION ]') +
                            chalk.white.bold(' | ') +
                            chalk.blue("".concat(new Date().toLocaleDateString())) +
                            chalk.white.bold(' | ') +
                            chalk.cyan('Slash Commands (/)') +
                            chalk.white(': ') +
                            chalk.greenBright("Refreshed"));
                        client === null || client === void 0 ? void 0 : client.user.setStatus(Configuration["default"].botPresence.status);
                        client === null || client === void 0 ? void 0 : client.user.setActivity(Configuration["default"].botPresence.activity, {
                            type: Configuration["default"].botPresence.activityType
                        });
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _g.sent();
                        console.log(chalk.greenBright('[ ANTICRASH ]') +
                            chalk.white.bold(' | ') +
                            chalk.red.bold("".concat(new Date().toLocaleDateString())) +
                            chalk.white.bold(' | ') +
                            chalk.cyan('Error reloading application (/) commands') +
                            chalk.white(': ') +
                            chalk.red.bold(error_1));
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    }
};
//# sourceMappingURL=ready.js.map