import { Events } from "discord.js";
import { Client } from "discord.js";
export let name: Events;
export let once: boolean;
/**
 *
 * @param {Client} client
 */
export function execute(client: Client<boolean>): Promise<void>;
//# sourceMappingURL=ready.d.ts.map