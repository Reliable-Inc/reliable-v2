export {};
//# sourceMappingURL=interactionCreate.d.ts.map