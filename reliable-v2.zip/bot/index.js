'use strict';
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
// Run checker.
require('./checker.js');
// All Modules/File Loading
var fs = __importStar(require("fs"));
var express_1 = __importDefault(require("express"));
var cors_1 = __importDefault(require("cors"));
var mongoose_1 = __importDefault(require("mongoose"));
var crypto_1 = __importDefault(require("crypto"));
var jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
var cookieParser = require('cookie-parser');
var discord_js_1 = require("discord.js");
var chalk_1 = __importDefault(require("chalk"));
var ServerKey_1 = __importDefault(require("./Schemas/ServerKey"));
var cb = __importStar(require("discordjs-colors-bundle"));
var Reports_1 = __importDefault(require("./Schemas/Reports"));
var Configuration = require('./config');
var axios_1 = __importDefault(require("axios"));
require('dotenv').config();
var clientId = process.env.ClientId;
console.log(clientId);
var clientSecret = process.env.ClientSecret;
console.log(clientId);
var redirectUri = Configuration["default"].redirectUri;
var app = (0, express_1["default"])();
var port = 3000;
var db = mongoose_1["default"].connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
// Express Server
app.use((0, cors_1["default"])());
app.use(express_1["default"].json());
app.use(cookieParser());
var validateServerKey = function (req, res, next) { return __awaiter(void 0, void 0, void 0, function () {
    var apiKey, serverKey, err_1;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                apiKey = req.headers['x-server-key'] || req.query.serverkey;
                if (!apiKey) {
                    return [2 /*return*/, res.status(401).json({ message: 'Server key is required.' })];
                }
                return [4 /*yield*/, ServerKey_1["default"].findOne({ key: apiKey })];
            case 1:
                serverKey = _a.sent();
                if (!serverKey) {
                    return [2 /*return*/, res.status(401).json({ message: 'Invalid API key.' })];
                }
                next();
                return [3 /*break*/, 3];
            case 2:
                err_1 = _a.sent();
                console.error(err_1);
                return [2 /*return*/, res.status(500).json({
                        message: 'Internal Server Error',
                        hint: {
                            error: err_1.message
                        }
                    })];
            case 3: return [2 /*return*/];
        }
    });
}); };
app.get('/', function (req, res) {
    var currentDate = new Date().toLocaleString();
    var clientIP = req.ip;
    var userAgent = req.headers['user-agent'];
    var language = req.headers['accept-language'];
    var encoding = req.headers['accept-encoding'];
    var message = "Welcome to Reliable Inc.!\nCurrent date: ".concat(currentDate, "\nYour IP address: ").concat(clientIP, "\nYour user agent: ").concat(userAgent, "\nYour language preference: ").concat(language, "\nYour encoding preference: ").concat(encoding);
    var styledMessage = "<div style=\"background-color: #1c1c1c; padding: 20px; color: white; font-family: Arial, sans-serif;\"> <h1 style=\"color: #ff9900; margin-bottom: 20px;\">Welcome to Reliable Inc.!</h1> <div style=\"display: flex; flex-direction: row;\"> <div style=\"flex: 1; margin-right: 20px;\"> <img src=\"https://cdn.discordapp.com/avatars/1030870443005071512/e95fc7583e69c92dab1612e8a3060181.webp?size=1024\" alt=\"Logo\" style=\"width: 200px;\"> </div> <div style=\"flex: 2;\"> <p style=\"font-size: 18px; line-height: 1.5; margin-bottom: 20px;\">".concat(message, "</p> <div style=\"background-color: #ff9900; color: #1c1c1c; padding: 10px; border-radius: 5px; display: inline-block;\"> <p style=\"margin: 0; font-weight: bold;\">Attention!</p> <p style=\"margin: 0;\">This project is for demonstration purposes only.</p> </div> </div> </div> <p style=\"margin-top: 20px;\">Thank you for visiting us today!</p> \n\n<p style=\"color: #666;\">Copyright &copy; Reliable Inc.</p>\n    </div>");
    res.status(200).set('Content-Type', 'text/html').send(styledMessage);
});
app.get('/api/v1/client.users', validateServerKey, function (req, res) {
    var _a, _b;
    try {
        var clientTotalUsers = (_b = (_a = client === null || client === void 0 ? void 0 : client.guilds) === null || _a === void 0 ? void 0 : _a.cache) === null || _b === void 0 ? void 0 : _b.reduce(function (a, b) { return a + b.memberCount; }, 0);
        return res.status(200).json({
            message: {
                body: {
                    status: {
                        message: 'OK',
                        code: 200
                    },
                    client: {
                        info: "Name: ".concat(client.user.tag),
                        total_users: clientTotalUsers
                    }
                }
            }
        });
    }
    catch (err) {
        console.error(err);
        return res.status(500).json({
            message: 'Internal Server Error',
            hint: {
                error: err === null || err === void 0 ? void 0 : err.message
            }
        });
    }
});
app.get('/api/v1/client.servers', validateServerKey, function (req, res) {
    var _a, _b;
    try {
        var clientTotalServers = (_b = (_a = client === null || client === void 0 ? void 0 : client.guilds) === null || _a === void 0 ? void 0 : _a.cache) === null || _b === void 0 ? void 0 : _b.size;
        return res.status(200).json({
            message: {
                body: {
                    status: {
                        message: 'OK',
                        code: 200
                    },
                    client: {
                        info: "Name: ".concat(client.user.tag),
                        total_servers: clientTotalServers
                    }
                }
            }
        });
    }
    catch (err) {
        console.error(err);
        return res.status(500).json({
            message: {
                body: {
                    status: {
                        message: 'Internal Server Error',
                        code: 500
                    },
                    hint: {
                        error: err === null || err === void 0 ? void 0 : err.message
                    }
                }
            }
        });
    }
});
app.get('/api/v1/client.info', validateServerKey, function (req, res) {
    var _a, _b, _c, _d;
    try {
        var clientTotalServers = (_b = (_a = client === null || client === void 0 ? void 0 : client.guilds) === null || _a === void 0 ? void 0 : _a.cache) === null || _b === void 0 ? void 0 : _b.size;
        var clientTotalUsers = (_d = (_c = client === null || client === void 0 ? void 0 : client.guilds) === null || _c === void 0 ? void 0 : _c.cache) === null || _d === void 0 ? void 0 : _d.reduce(function (a, b) { return a + b.memberCount; }, 0);
        return res.status(200).json({
            message: {
                body: {
                    status: {
                        message: 'OK',
                        code: 200
                    },
                    client: {
                        info: {
                            name: client === null || client === void 0 ? void 0 : client.user.tag,
                            total_guilds: clientTotalServers,
                            total_users: clientTotalUsers
                        }
                    }
                }
            }
        });
    }
    catch (err) {
        console.error(err);
        return res.status(500).json({
            message: {
                body: {
                    status: {
                        message: 'Internal Server Error',
                        code: 500
                    },
                    hint: {
                        error: err === null || err === void 0 ? void 0 : err.message
                    }
                }
            }
        });
    }
});
app.post('/api/v1/embed.send', validateServerKey, function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var _a, e_title, e_desc, _b, e_footer, _c, e_color, channel_id, color, channel, desc, Embed, error_1;
    return __generator(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = req.query, e_title = _a.e_title, e_desc = _a.e_desc, _b = _a.e_footer, e_footer = _b === void 0 ? 'Reliable' : _b, _c = _a.e_color, e_color = _c === void 0 ? 'Red' : _c, channel_id = _a.channel_id;
                color = e_color;
                if (!e_title || !e_desc || !channel_id) {
                    return [2 /*return*/, res.status(404).json({
                            message: {
                                body: {
                                    status: {
                                        message: 'Not found',
                                        code: 404
                                    },
                                    error: {
                                        hint: 'A required value is not provided.',
                                        values: ['e_title', 'e_desc', 'channel_id']
                                    }
                                }
                            }
                        })];
                }
                channel = client === null || client === void 0 ? void 0 : client.channels.cache.get(channel_id.toString());
                desc = e_desc.replace(/\\n/g, '\n');
                Embed = new discord_js_1.EmbedBuilder()
                    .setTitle(e_title.toString())
                    .setDescription(desc.toString())
                    .setColor(color.toString() in cb.Colors
                    ? cb.Colors[e_color.toString()]
                    : e_color.toString())
                    .setFooter({ text: e_footer.toString() });
                _d.label = 1;
            case 1:
                _d.trys.push([1, 3, , 4]);
                return [4 /*yield*/, channel.send({ embeds: [Embed] })];
            case 2:
                _d.sent();
                res.status(200).json({
                    message: {
                        body: {
                            status: {
                                message: 'OK',
                                code: 200
                            },
                            sent: 1,
                            embed_body: {
                                title: e_title,
                                description: desc,
                                color: e_color,
                                footer: e_footer,
                                to_channel: channel_id
                            }
                        }
                    }
                });
                return [3 /*break*/, 4];
            case 3:
                error_1 = _d.sent();
                console.error('Error sending message:', error_1);
                res.status(500).json({
                    message: {
                        body: {
                            status: {
                                message: 'Internal Server Error',
                                code: 500
                            },
                            error: {
                                hint: 'An error occurred while sending the message.'
                            }
                        }
                    }
                });
                return [3 /*break*/, 4];
            case 4: return [2 /*return*/];
        }
    });
}); });
app.post('/api/v1/bug.submit', validateServerKey, function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var _a, bug_title, bug_desc, bug_exp, reported_by, reported_pfp, reported_date, _b, e_footer, _c, e_color, channelId, newReport, channel, desc, Embed, error_2;
    return __generator(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = req.query, bug_title = _a.bug_title, bug_desc = _a.bug_desc, bug_exp = _a.bug_exp, reported_by = _a.reported_by, reported_pfp = _a.reported_pfp, reported_date = _a.reported_date, _b = _a.e_footer, e_footer = _b === void 0 ? 'Reliable' : _b, _c = _a.e_color, e_color = _c === void 0 ? 'Red' : _c;
                channelId = '1029808315481460798';
                if (!bug_title ||
                    !bug_desc ||
                    !bug_exp ||
                    !reported_by ||
                    !reported_pfp ||
                    !reported_date) {
                    return [2 /*return*/, res.status(404).json({
                            message: {
                                body: {
                                    status: {
                                        message: 'Not found',
                                        code: 404
                                    },
                                    error: {
                                        hint: 'A required value was not provided.',
                                        values: [
                                            'bug_title',
                                            'bug_desc',
                                            'bug_exp',
                                            'reported_by',
                                            'reported_pfp',
                                            'reported_date',
                                        ]
                                    }
                                }
                            }
                        })];
                }
                newReport = new Reports_1["default"]({
                    BugTitle: bug_title,
                    BugDescription: bug_desc,
                    BugExpectation: bug_exp,
                    ReportedBy: reported_by,
                    ReportedPfp: reported_pfp,
                    ReportedDate: reported_date
                });
                channel = client === null || client === void 0 ? void 0 : client.channels.cache.get(channelId.toString());
                desc = bug_desc.replace(/\\n/g, '\n');
                Embed = new discord_js_1.EmbedBuilder()
                    .setTitle(bug_title.toString())
                    .setDescription("".concat(desc.toString(), "\n\n").concat(bug_exp.toString(), "\n\n### Reported By: ").concat(reported_by))
                    .setColor(cb.Colors[e_color.toString()] || e_color.toString())
                    .setFooter({ text: e_footer.toString() })
                    .setThumbnail(reported_pfp);
                _d.label = 1;
            case 1:
                _d.trys.push([1, 4, , 5]);
                return [4 /*yield*/, channel.send({ embeds: [Embed] })];
            case 2:
                _d.sent();
                return [4 /*yield*/, newReport.save()];
            case 3:
                _d.sent();
                res.status(200).json({
                    message: {
                        body: {
                            status: {
                                message: 'OK',
                                code: 200
                            },
                            sent: 1,
                            embed_body: {
                                bugTitle: bug_title,
                                description: {
                                    bugDescription: bug_desc,
                                    bugExpectation: bug_exp
                                },
                                reports: {
                                    reported_by: reported_by,
                                    reported_user_pfp: reported_pfp,
                                    reported_date: reported_date
                                },
                                color: e_color,
                                footer: e_footer,
                                to_channel: channelId
                            }
                        }
                    }
                });
                return [3 /*break*/, 5];
            case 4:
                error_2 = _d.sent();
                console.error('Error sending message:', error_2);
                res.status(500).json({
                    message: {
                        body: {
                            status: {
                                message: 'Internal Server Error',
                                code: 500
                            },
                            error: {
                                hint: 'An error occurred while sending the message.'
                            }
                        }
                    }
                });
                return [3 /*break*/, 5];
            case 5: return [2 /*return*/];
        }
    });
}); });
app.get('/api/v1/bug.views', validateServerKey, function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var bugReports, error_3;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                return [4 /*yield*/, Reports_1["default"].find()];
            case 1:
                bugReports = _a.sent();
                if (!bugReports) {
                    return [2 /*return*/, res.status(200).json({ message: "There's no bug reports." })];
                }
                res.status(200).json(bugReports);
                return [3 /*break*/, 3];
            case 2:
                error_3 = _a.sent();
                res.status(500).json({
                    message: 'Internal Server Error',
                    error: error_3.message
                });
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); });
// DELETE route: Delete a specific bug report
app["delete"]('/api/v1/bug.delete', validateServerKey, function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var _a, bug_report_title, bug_report_by, error_4;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                _a = req.query, bug_report_title = _a.bug_report_title, bug_report_by = _a.bug_report_by;
                _b.label = 1;
            case 1:
                _b.trys.push([1, 3, , 4]);
                return [4 /*yield*/, Reports_1["default"].findOneAndDelete({
                        BugTitle: bug_report_title,
                        ReportedBy: bug_report_by
                    })];
            case 2:
                _b.sent();
                res.status(200).json({
                    message: 'Bug report deleted successfully'
                });
                return [3 /*break*/, 4];
            case 3:
                error_4 = _b.sent();
                res.status(500).json({
                    message: 'Internal Server Error',
                    error: error_4.message
                });
                return [3 /*break*/, 4];
            case 4: return [2 /*return*/];
        }
    });
}); });
app.listen(port, function () {
    console.log(chalk_1["default"].cyan('[ INFORMATION ]') +
        chalk_1["default"].white.bold(' | ') +
        chalk_1["default"].blue("".concat(new Date().toLocaleDateString())) +
        chalk_1["default"].white.bold(' | ') +
        chalk_1["default"].cyan('Server started on port') +
        chalk_1["default"].white(': ') +
        chalk_1["default"].greenBright("".concat(port)));
});
// Intents Zone
var client = new discord_js_1.Client({
    intents: [
        discord_js_1.GatewayIntentBits.AutoModerationConfiguration,
        discord_js_1.GatewayIntentBits.AutoModerationExecution,
        discord_js_1.GatewayIntentBits.DirectMessageReactions,
        discord_js_1.GatewayIntentBits.DirectMessageTyping,
        discord_js_1.GatewayIntentBits.DirectMessages,
        discord_js_1.GatewayIntentBits.GuildEmojisAndStickers,
        discord_js_1.GatewayIntentBits.GuildIntegrations,
        discord_js_1.GatewayIntentBits.GuildInvites,
        discord_js_1.GatewayIntentBits.GuildMembers,
        discord_js_1.GatewayIntentBits.GuildMessageReactions,
        discord_js_1.GatewayIntentBits.GuildMessageTyping,
        discord_js_1.GatewayIntentBits.GuildMessages,
        discord_js_1.GatewayIntentBits.GuildModeration,
        discord_js_1.GatewayIntentBits.GuildPresences,
        discord_js_1.GatewayIntentBits.GuildScheduledEvents,
        discord_js_1.GatewayIntentBits.GuildVoiceStates,
        discord_js_1.GatewayIntentBits.GuildWebhooks,
        discord_js_1.GatewayIntentBits.Guilds,
        discord_js_1.GatewayIntentBits.MessageContent,
    ],
    partials: [
        discord_js_1.Partials.Channel,
        discord_js_1.Partials.GuildMember,
        discord_js_1.Partials.GuildScheduledEvent,
        discord_js_1.Partials.Message,
        discord_js_1.Partials.Reaction,
        discord_js_1.Partials.ThreadMember,
        discord_js_1.Partials.User,
    ]
});
// Collections Manager
client.commands = new discord_js_1.Collection();
client.buttons = new discord_js_1.Collection();
client.selectMenus = new discord_js_1.Collection();
client.modals = new discord_js_1.Collection();
var oauthUrl = "https://discord.com/api/oauth2/authorize?client_id=".concat(clientId, "&redirect_uri=").concat(encodeURIComponent(redirectUri), "&response_type=code&scope=identify email");
app.get('/login', function (req, res) {
    res.redirect(oauthUrl);
});
app.get('/callback', function (_a, response) {
    var query = _a.query;
    return __awaiter(void 0, void 0, void 0, function () {
        var code, tokenResponse, oauthData, error_5;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    code = query.code;
                    if (!code) return [3 /*break*/, 4];
                    _b.label = 1;
                case 1:
                    _b.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, axios_1["default"].post('https://discord.com/api/oauth2/token', new URLSearchParams({
                            client_id: clientId,
                            client_secret: clientSecret,
                            code: code,
                            grant_type: 'authorization_code',
                            redirect_uri: "https://reliable-v2.mohtasimalamsoh.repl.co/callback",
                            scope: 'identify email'
                        }).toString(), {
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded'
                            }
                        })];
                case 2:
                    tokenResponse = _b.sent();
                    oauthData = tokenResponse.data;
                    response.cookie('access_token', oauthData.access_token);
                    response.cookie('token_type', oauthData.token_type);
                    return [3 /*break*/, 4];
                case 3:
                    error_5 = _b.sent();
                    // NOTE: An unauthorized token will not throw an error
                    // tokenResponse.status will be 401
                    console.error(error_5);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/, response.send('Success!')];
            }
        });
    });
});
app.get('/api/v1/user.info', validateServerKey, function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var tokenType, accessToken, userResult;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                tokenType = req.cookies.token_type;
                accessToken = req.cookies.access_token;
                return [4 /*yield*/, axios_1["default"].get('https://discord.com/api/users/@me', {
                        headers: {
                            Authorization: "".concat(tokenType, " ").concat(accessToken)
                        }
                    })];
            case 1:
                userResult = _a.sent();
                if (userResult.status == 401 || userResult.status == 404) {
                    return [2 /*return*/, res.status(601).json({
                            body: {
                                hint: 'Multiple problems while fetching a ThirdParty API.',
                                status: {
                                    message: 'API Fetch Error',
                                    code: 601
                                }
                            }
                        })];
                }
                res.status(200).json(userResult.data);
                return [2 /*return*/];
        }
    });
}); });
// Commands
var commandFolder = fs.readdirSync('./Commands');
for (var _i = 0, commandFolder_1 = commandFolder; _i < commandFolder_1.length; _i++) {
    var folder = commandFolder_1[_i];
    var commandFiles = fs
        .readdirSync("./Commands/".concat(folder))
        .filter(function (file) { return file.endsWith('.js'); });
    for (var _a = 0, commandFiles_1 = commandFiles; _a < commandFiles_1.length; _a++) {
        var file = commandFiles_1[_a];
        var command = require("./Commands/".concat(folder, "/").concat(file));
        client.commands.set(command.data.name, command);
    }
}
// Event Manager
var eventFolder = fs.readdirSync('./Events');
for (var _b = 0, eventFolder_1 = eventFolder; _b < eventFolder_1.length; _b++) {
    var folder = eventFolder_1[_b];
    var eventFiles = fs
        .readdirSync("./Events/".concat(folder))
        .filter(function (file) { return file.endsWith('.js'); });
    var _loop_1 = function (file) {
        var event_1 = require("./Events/".concat(folder, "/").concat(file));
        if (event_1.once) {
            client.once(event_1.name, function () {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                return event_1.execute.apply(event_1, __spreadArray(__spreadArray([], args, false), [client], false));
            });
        }
        else {
            client.on(event_1.name, function () {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                return event_1.execute.apply(event_1, __spreadArray(__spreadArray([], args, false), [client], false));
            });
        }
    };
    for (var _c = 0, eventFiles_1 = eventFiles; _c < eventFiles_1.length; _c++) {
        var file = eventFiles_1[_c];
        _loop_1(file);
    }
}
// Components Manager
var componentsFolder = fs.readdirSync('./Components');
for (var _d = 0, componentsFolder_1 = componentsFolder; _d < componentsFolder_1.length; _d++) {
    var folder = componentsFolder_1[_d];
    var componentsFile = fs
        .readdirSync("./Components/".concat(folder))
        .filter(function (file) { return file.endsWith('.js'); });
    switch (folder) {
        case 'buttons':
            {
                for (var _e = 0, componentsFile_1 = componentsFile; _e < componentsFile_1.length; _e++) {
                    var file = componentsFile_1[_e];
                    var button = require("./Components/".concat(folder, "/").concat(file));
                    client.buttons.set(button.data.name, button);
                }
            }
            break;
        case 'selectMenus':
            {
                for (var _f = 0, componentsFile_2 = componentsFile; _f < componentsFile_2.length; _f++) {
                    var file = componentsFile_2[_f];
                    var menu = require("./Components/".concat(folder, "/").concat(file));
                    client.selectMenus.set(menu.data.name, menu);
                }
            }
            break;
        case 'modals': {
            for (var _g = 0, componentsFile_3 = componentsFile; _g < componentsFile_3.length; _g++) {
                var file = componentsFile_3[_g];
                var modal = require("./Components/".concat(folder, "/").concat(file));
                client.modals.set(modal.data.name, modal);
            }
        }
        default:
            break;
    }
}
//AntiCrash Manager
console.log(chalk_1["default"].cyan('[ INFORMATION ]') +
    chalk_1["default"].white.bold(' | ') +
    chalk_1["default"].blue("".concat(new Date().toLocaleDateString())) +
    chalk_1["default"].white.bold(' | ') +
    chalk_1["default"].cyan('AntiCrash Connection') +
    chalk_1["default"].white(': ') +
    chalk_1["default"].greenBright("Connected"));
process.on('unhandledRejection', function (reason, p) {
    console.log(chalk_1["default"].greenBright('[ ANTICRASH ]') +
        chalk_1["default"].white.bold(' | ') +
        chalk_1["default"].red.bold("".concat(new Date().toLocaleDateString())) +
        chalk_1["default"].white.bold(' | ') +
        chalk_1["default"].cyan('Unhandled') +
        chalk_1["default"].white(': ') +
        chalk_1["default"].red.bold("Rejection/Catch"));
    console.log(reason, p);
});
process.on('uncaughtException', function (err, origin) {
    console.log(chalk_1["default"].greenBright('[ ANTICRASH ]') +
        chalk_1["default"].white.bold(' | ') +
        chalk_1["default"].red.bold("".concat(new Date().toLocaleDateString())) +
        chalk_1["default"].white.bold(' | ') +
        chalk_1["default"].cyan('Uncaught') +
        chalk_1["default"].white(': ') +
        chalk_1["default"].red.bold("Exception/Catch"));
    console.log(err, origin);
});
process.on('uncaughtExceptionMonitor', function (err, origin) {
    console.log(chalk_1["default"].greenBright('[ ANTICRASH ]') +
        chalk_1["default"].white.bold(' | ') +
        chalk_1["default"].red.bold("".concat(new Date().toLocaleDateString())) +
        chalk_1["default"].white.bold(' | ') +
        chalk_1["default"].cyan('Uncaught') +
        chalk_1["default"].white(': ') +
        chalk_1["default"].red.bold("Exception/Catch (MONITOR)"));
    console.log(err, origin);
});
client.login(process.env.Token);
//# sourceMappingURL=index.js.map