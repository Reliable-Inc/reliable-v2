export default roleId;
declare let roleId: any;
//# sourceMappingURL=setup.d.ts.map