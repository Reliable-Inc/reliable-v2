"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var discord_js_1 = require("discord.js");
var discordjs_colors_bundle_1 = require("discordjs-colors-bundle");
var VerificationSchema_1 = __importDefault(require("../../Schemas/VerificationSchema"));
var AntiToxic_1 = __importDefault(require("../../Schemas/AntiToxic"));
var AntiThreat_1 = __importDefault(require("../../Schemas/AntiThreat"));
var antiInsult_1 = __importDefault(require("../../Schemas/antiInsult"));
var AntiObscene_1 = __importDefault(require("../../Schemas/AntiObscene"));
var roleId = null;
module.exports = {
    beta: true,
    data: new discord_js_1.SlashCommandBuilder()
        .setName('setup')
        .setDescription('Setup command.')
        .addSubcommand(function (sub) {
        return sub
            .setName('verification')
            .setDescription('Setup verification for your server.')
            .addRoleOption(function (op) {
            return op
                .setName('role')
                .setDescription('The verified role')
                .setRequired(true);
        })
            .addChannelOption(function (op) {
            return op
                .setName('channel')
                .setDescription('The channel to send the verification embed')
                .setRequired(true);
        })
            .addStringOption(function (op) {
            return op
                .setName('embed-title')
                .setDescription('The embed title for your verification embed.')
                .setRequired(false);
        })
            .addStringOption(function (op) {
            return op
                .setName('description')
                .setDescription('The description of the embed')
                .setRequired(false);
        })
            .addStringOption(function (op) {
            return op
                .setName('footer')
                .setDescription('The embed footer')
                .setRequired(false);
        })
            .addStringOption(function (op) {
            return op
                .setName('image')
                .setDescription('Any image you need for the embed?')
                .setRequired(false);
        })
            .addStringOption(function (op) {
            return op
                .setName('color')
                .setDescription('The color for the embed.')
                .setRequired(false);
        })
            .addStringOption(function (op) {
            return op
                .setName('button-name')
                .setDescription('The name of the button.')
                .setRequired(false);
        })
            .addStringOption(function (op) {
            return op
                .setName('button-color')
                .setDescription('The color for the button.')
                .addChoices({ name: 'Green', value: 'success' }, { name: 'Blue', value: 'primary' }, { name: 'Gray', value: 'secondary' }, { name: 'Red', value: 'danger' })
                .setRequired(false);
        })
            .addStringOption(function (op) {
            return op
                .setName('button-emoji')
                .setDescription('The emoji for the button.')
                .setRequired(false);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('anti-toxic')
            .setDescription('Setup Anti Toxic for your server.');
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('anti-threat')
            .setDescription('Setup Anti Threating for your server.');
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('anti-insult')
            .setDescription('Setup Anti Insulting for your server.');
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('anti-obscene')
            .setDescription('Setup Anti Obscening for your server.');
    }),
    /**
     *
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    execute: function (interaction, client) {
        var _a, _b, _c, _d, _e;
        return __awaiter(this, void 0, void 0, function () {
            var title, description, footerText, color, image, channelId, channel, role, btnColor, btnTitle, btnEmoji, guildId, Embed, button, existingRole, newRole, buttons, buttons, guildId, alreadyEnabled, GuildIDData, guildId, alreadyEnabled, GuildIDData, guildId, alreadyEnabled, GuildIDData, guildId, alreadyEnabled, GuildIDData;
            return __generator(this, function (_f) {
                switch (_f.label) {
                    case 0:
                        if (!(interaction.options.getSubcommand() == 'verification')) return [3 /*break*/, 6];
                        roleId = interaction.options.getRole('role').id;
                        title = interaction.options.getString('embed-title');
                        description = interaction.options.getString('description');
                        footerText = interaction.options.getString('footer');
                        color = (_a = interaction.options.getString('color')) !== null && _a !== void 0 ? _a : '#2F3136';
                        image = (_b = interaction.options.getString('image')) !== null && _b !== void 0 ? _b : 0;
                        channelId = interaction.options.getChannel('channel').id;
                        channel = client === null || client === void 0 ? void 0 : client.channels.cache.get(channelId);
                        role = interaction === null || interaction === void 0 ? void 0 : interaction.guild.roles.cache.find(function (r) { return r.name === roleId; });
                        btnColor = (_c = interaction === null || interaction === void 0 ? void 0 : interaction.options.getString('button-color')) !== null && _c !== void 0 ? _c : 'secondary';
                        btnTitle = (_d = interaction === null || interaction === void 0 ? void 0 : interaction.options.getString('button-name')) !== null && _d !== void 0 ? _d : 'Verification';
                        btnEmoji = (_e = interaction === null || interaction === void 0 ? void 0 : interaction.options.getString('button-emoji')) !== null && _e !== void 0 ? _e : '<:reliable_right:1042843202429919272>';
                        guildId = interaction === null || interaction === void 0 ? void 0 : interaction.guild.id;
                        Embed = new discord_js_1.EmbedBuilder();
                        button = new discord_js_1.ButtonBuilder()
                            .setCustomId('verifyBtn')
                            .setLabel(btnTitle)
                            .setEmoji(btnEmoji);
                        return [4 /*yield*/, VerificationSchema_1["default"].findOne({ guildId: guildId })];
                    case 1:
                        existingRole = _f.sent();
                        if (!existingRole) return [3 /*break*/, 3];
                        existingRole.roleId = roleId;
                        return [4 /*yield*/, existingRole.save()];
                    case 2:
                        _f.sent();
                        return [3 /*break*/, 5];
                    case 3:
                        newRole = new VerificationSchema_1["default"]({ guildId: guildId, roleId: roleId });
                        return [4 /*yield*/, newRole.save()];
                    case 4:
                        _f.sent();
                        _f.label = 5;
                    case 5:
                        if (image) {
                            Embed.setColor(discordjs_colors_bundle_1.Colors[color] || color)
                                .setTitle("".concat(title || "Verification for ".concat(interaction.guild.name)))
                                .setDescription("".concat(description ||
                                'We kindly invite you to click the grey button provided below to acquire the coveted role mentioned subsequently. This esteemed role will grant you access to exclusive privileges and enhanced functionalities within our community. By initiating this action, you will embark upon a journey of elevated engagement and enriched experiences. Seize the opportunity to unlock the potential that awaits you.'))
                                .setFooter({
                                text: "".concat(footerText || 'Reliable | Your trusted assistant')
                            })
                                .addFields({
                                name: '__Role__',
                                value: "**`\u00BB`** <@&".concat(roleId, ">")
                            })
                                .setImage(image)
                                .setTimestamp();
                            if (btnColor === 'success') {
                                button.setStyle(discord_js_1.ButtonStyle.Success);
                            }
                            else if (btnColor === 'danger') {
                                button.setStyle(discord_js_1.ButtonStyle.Danger);
                            }
                            else if (btnColor === 'primary') {
                                button.setStyle(discord_js_1.ButtonStyle.Primary);
                            }
                            else {
                                button.setStyle(discord_js_1.ButtonStyle.Secondary);
                            }
                            buttons = new discord_js_1.ActionRowBuilder().addComponents(button);
                            return [2 /*return*/, channel.send({ embeds: [Embed], components: [buttons] })];
                        }
                        else {
                            Embed.setColor(discordjs_colors_bundle_1.Colors[color] || color)
                                .setTitle("".concat(title || "Verification for ".concat(interaction.guild.name)))
                                .addFields({
                                name: '__Role__',
                                value: "**`\u00BB`** <@&".concat(roleId, ">")
                            })
                                .setDescription("".concat(description ||
                                'We kindly invite you to click the grey button provided below to acquire the coveted role mentioned subsequently. This esteemed role will grant you access to exclusive privileges and enhanced functionalities within our community. By initiating this action, you will embark upon a journey of elevated engagement and enriched experiences. Seize the opportunity to unlock the potential that awaits you.'))
                                .setFooter({
                                text: "".concat(footerText || 'Reliable | Your trusted assistant')
                            })
                                .setTimestamp();
                            if (btnColor === 'success') {
                                button.setStyle(discord_js_1.ButtonStyle.Success);
                            }
                            else if (btnColor === 'danger') {
                                button.setStyle(discord_js_1.ButtonStyle.Danger);
                            }
                            else if (btnColor === 'primary') {
                                button.setStyle(discord_js_1.ButtonStyle.Primary);
                            }
                            else {
                                button.setStyle(discord_js_1.ButtonStyle.Secondary);
                            }
                            buttons = new discord_js_1.ActionRowBuilder().addComponents(button);
                            return [2 /*return*/, channel.send({ embeds: [Embed], components: [buttons] })];
                        }
                        return [3 /*break*/, 18];
                    case 6:
                        if (!(interaction.options.getSubcommand() == 'anti-toxic')) return [3 /*break*/, 9];
                        guildId = interaction === null || interaction === void 0 ? void 0 : interaction.guild.id;
                        return [4 /*yield*/, AntiToxic_1["default"].findOne({ guildId: guildId })];
                    case 7:
                        alreadyEnabled = _f.sent();
                        if (alreadyEnabled) {
                            return [2 /*return*/, interaction.reply({ content: 'Anti-Toxic is already enabled.' })];
                        }
                        GuildIDData = new AntiToxic_1["default"]({ guildId: guildId });
                        return [4 /*yield*/, GuildIDData.save()];
                    case 8:
                        _f.sent();
                        return [2 /*return*/, interaction.reply({ content: 'Successfully Enabled Anti-Toxic!' })];
                    case 9:
                        if (!(interaction.options.getSubcommand() == 'anti-threat')) return [3 /*break*/, 12];
                        guildId = interaction === null || interaction === void 0 ? void 0 : interaction.guild.id;
                        return [4 /*yield*/, AntiThreat_1["default"].findOne({ guildId: guildId })];
                    case 10:
                        alreadyEnabled = _f.sent();
                        if (alreadyEnabled) {
                            return [2 /*return*/, interaction.reply({
                                    content: 'Anti-Threat is already enabled.'
                                })];
                        }
                        GuildIDData = new AntiThreat_1["default"]({ guildId: guildId });
                        return [4 /*yield*/, GuildIDData.save()];
                    case 11:
                        _f.sent();
                        return [2 /*return*/, interaction.reply({
                                content: 'Successfully Enabled Anti-Threating!'
                            })];
                    case 12:
                        if (!(interaction.options.getSubcommand() == 'anti-insult')) return [3 /*break*/, 15];
                        guildId = interaction === null || interaction === void 0 ? void 0 : interaction.guild.id;
                        return [4 /*yield*/, antiInsult_1["default"].findOne({ guildId: guildId })];
                    case 13:
                        alreadyEnabled = _f.sent();
                        if (alreadyEnabled) {
                            return [2 /*return*/, interaction.reply({
                                    content: 'Anti-Insult is already enabled.'
                                })];
                        }
                        GuildIDData = new antiInsult_1["default"]({ guildId: guildId });
                        return [4 /*yield*/, GuildIDData.save()];
                    case 14:
                        _f.sent();
                        return [2 /*return*/, interaction.reply({
                                content: 'Successfully Enabled Anti-Insult!'
                            })];
                    case 15:
                        if (!(interaction.options.getSubcommand() == 'anti-obscene')) return [3 /*break*/, 18];
                        guildId = interaction === null || interaction === void 0 ? void 0 : interaction.guild.id;
                        return [4 /*yield*/, AntiObscene_1["default"].findOne({ guildId: guildId })];
                    case 16:
                        alreadyEnabled = _f.sent();
                        if (alreadyEnabled) {
                            return [2 /*return*/, interaction.reply({
                                    content: 'Anti-Obscene is already enabled.'
                                })];
                        }
                        GuildIDData = new AntiObscene_1["default"]({ guildId: guildId });
                        return [4 /*yield*/, GuildIDData.save()];
                    case 17:
                        _f.sent();
                        return [2 /*return*/, interaction.reply({
                                content: 'Successfully Enabled Anti-Obscene!'
                            })];
                    case 18: return [2 /*return*/];
                }
            });
        });
    }
};
exports["default"] = roleId;
//# sourceMappingURL=setup.js.map