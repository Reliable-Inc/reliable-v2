"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require('discord.js'), SlashCommandBuilder = _a.SlashCommandBuilder, ChatInputCommandInteraction = _a.ChatInputCommandInteraction, ButtonBuilder = _a.ButtonBuilder, ButtonStyle = _a.ButtonStyle, EmbedBuilder = _a.EmbedBuilder, Embed = _a.Embed, Colors = _a.Colors, ActionRowBuilder = _a.ActionRowBuilder, AuditLogEvent = _a.AuditLogEvent, Events = _a.Events, GuildMemberManager = _a.GuildMemberManager, PermissionsBitField = _a.PermissionsBitField, PermissionFlagsBits = _a.PermissionFlagsBits;
var e = require('express');
var ms = require('ms');
module.exports = {
    beta: false,
    data: new SlashCommandBuilder()
        .setName('moderation')
        .setDescription('Moderation commands')
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers ||
        PermissionFlagsBits.Administrator ||
        PermissionFlagsBits.KickMembers ||
        PermissionFlagsBits.ManageMessages ||
        PermissionFlagsBits.ManageRoles ||
        PermissionFlagsBits.TimeoutMembers)
        .addSubcommand(function (sub) {
        return sub
            .setName('ban')
            .setDescription('Ban a member from your guild.')
            .addUserOption(function (op) {
            return op
                .setName('target')
                .setDescription('Select the user who you want to ban')
                .setRequired(true);
        })
            .addStringOption(function (op) {
            return op
                .setName('reason')
                .setDescription('Provide a reason for ban')
                .setRequired(false);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('lock')
            .setDescription('Lock the Channel for everyone, nobody can write messages anymore.')
            .addChannelOption(function (op) {
            return op
                .setName('channel')
                .setDescription('Mention the channel')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('unlock')
            .setDescription('Unlock the Channel for everyone, everyone can write messages anymore.')
            .addChannelOption(function (op) {
            return op
                .setName('channel')
                .setDescription('Mention the channel')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('addrole')
            .setDescription('Adds role to a user')
            .addUserOption(function (op) {
            return op.setName('user').setDescription('Select the user').setRequired(true);
        })
            .addRoleOption(function (op) {
            return op.setName('role').setDescription('Select the role').setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('removerole')
            .setDescription('Removes role to a user')
            .addUserOption(function (op) {
            return op.setName('user').setDescription('Select the user').setRequired(true);
        })
            .addRoleOption(function (op) {
            return op.setName('role').setDescription('Select the role').setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('setnick')
            .setDescription('Sets nick to a user')
            .addUserOption(function (op) {
            return op.setName('user').setDescription('Select the user').setRequired(true);
        })
            .addStringOption(function (op) {
            return op
                .setName('nickname')
                .setDescription('Provide nickname')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('list-bans')
            .setDescription('List banned user of this server.');
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('kick')
            .setDescription('kick a member from this guild.')
            .addUserOption(function (op) {
            return op
                .setName('target')
                .setDescription('Select a member who you want to kick')
                .setRequired(true);
        })
            .addStringOption(function (op) {
            return op
                .setName('reason')
                .setDescription('Provide a reason for kick')
                .setRequired(false);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('clear')
            .setDescription('Clear a specified amount of message.')
            .addIntegerOption(function (option) {
            return option
                .setName('amount')
                .setDescription('Enter amount to clear message')
                .setRequired(true);
        })
            .addUserOption(function (op) {
            return op
                .setName('target')
                .setDescription('Select a user who you wants to clear')
                .setRequired(false);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('timeout')
            .setDescription('timeout a member from this guild.')
            .addUserOption(function (op) {
            return op
                .setName('target')
                .setDescription('Select a member who you want to timeout')
                .setRequired(true);
        })
            .addIntegerOption(function (op) {
            return op
                .setName('time')
                .setDescription('set the time for timeout (in minutes)')
                .setRequired(true);
        })
            .addStringOption(function (op) {
            return op
                .setName('reason')
                .setDescription('Provide a reason for timeout')
                .setRequired(false);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('role-member-info')
            .setDescription('Shows list of members having a role.')
            .addRoleOption(function (op) {
            return op.setName('role').setDescription('Select a role').setRequired(true);
        });
    }),
    execute: function (interaction, client) {
        return __awaiter(this, void 0, void 0, function () {
            var channel, options, user, reason, member, err_embed, err2_embed, err2_embed, err59_embed, err2_embed, err2_embed, bannedEmbed, channel, options, user, reason, member, err_embed, err2_embed, err59_embed, err3_embed, err2_embed, err2_embed, err2_embed, kickedEmbed, channel, options, Amount_1, Target_1, Messages, Response_1, i_1, filtered_1, channel, options, user, reason, time, member, error_embed, err2_embed, err2_embed, error2_embed, err2_embed, timoutEMBED, channel, err_embed, lockedembed, channel, unlockedembed, amount, fetchBans, bannedMembers, bannedlist, role_1, membersWithRole, err_embed, rolemember, role, member, err2_embed, err2_embed, error2_embed, err2_embed, err_embed4, embed, role, member, guild, err2_embed, err2_embed, error2_embed, err2_embed, err_embed4, embed, nickname, member, err2_embed, err2_embed, error2_embed, err2_embed, err_embed4, oldNickname, embed;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(interaction.options.getSubcommand() === 'ban')) return [3 /*break*/, 3];
                        channel = interaction.channel, options = interaction.options;
                        user = options.getUser('target') || "You can't ban yourself!";
                        reason = interaction.options.getString('reason');
                        return [4 /*yield*/, interaction.guild.members
                                .fetch(user.id)["catch"](console.error)];
                    case 1:
                        member = _a.sent();
                        if (!reason)
                            reason = 'No reason provided';
                        if (member.id === interaction.user.id) {
                            err_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot ban yourself!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err_embed], ephemeral: true })];
                        }
                        if (member.id === interaction.client.user.id) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot ban me!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (member.id === interaction.guild.ownerId) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot ban the owner!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (!member.bannable) {
                            err59_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | The mentioned user is not bannable!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err59_embed], ephemeral: true })];
                        }
                        if (interaction.member.roles.highest.position <
                            member.roles.highest.position) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot ban a user who have higher role than you!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (client.user.roles.highest.position < member.roles.highest.position) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | I cannot ban user who have higher role than me!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        member.ban({ deleteMessageDays: 1, reason: reason })["catch"](console.error);
                        bannedEmbed = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .setTitle("Banned a member..")
                            .addFields({
                            name: '‣ Banned',
                            value: "**`".concat(user.tag, "`**"),
                            inline: true
                        }, {
                            name: '‣ Reason',
                            value: "**`".concat(reason, "`**"),
                            inline: true
                        });
                        interaction.channel.send({ embeds: [bannedEmbed] });
                        return [4 /*yield*/, interaction.reply({
                                content: "Done. Banned ".concat(user.tag),
                                ephemeral: true
                            })];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 27];
                    case 3:
                        if (!(interaction.options.getSubcommand() === 'kick')) return [3 /*break*/, 6];
                        channel = interaction.channel, options = interaction.options;
                        user = options.getUser('target');
                        reason = interaction.options.getString('reason');
                        return [4 /*yield*/, interaction.guild.members
                                .fetch(user.id)["catch"](console.error)];
                    case 4:
                        member = _a.sent();
                        if (!reason)
                            reason = 'No reason provided';
                        if (member.id === interaction.user.id) {
                            err_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot kick yourself!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err_embed], ephemeral: true })];
                        }
                        if (member.id === interaction.client.user.id) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | I cannot kick myself**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (!member.kickable) {
                            err59_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | The mentioned user is not kickable!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err59_embed], ephemeral: true })];
                        }
                        if (!member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
                            err3_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription("**<:reliable_wrong:1043155193077960764> | You can't kick the member! You need `Kick Members` Permission**")
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err3_embed], ephemeral: true })];
                        }
                        if (member.id === interaction.guild.ownerId) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot kick the owner!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (interaction.member.roles.highest.position <
                            member.roles.highest.position) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot kick a user who have higher role than you!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (client.user.roles.highest.position < member.roles.highest.position) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | I cannot kick a user who have higher role than me!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        member.kick(reason)["catch"](console.error);
                        kickedEmbed = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setTitle("Kicked a member..")
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .addFields({
                            name: '‣ Kicked',
                            value: "**`".concat(user.tag, "`**"),
                            inline: true
                        }, {
                            name: '‣ Reason',
                            value: "**`".concat(reason, "`**"),
                            inline: true
                        });
                        interaction.channel.send({ embeds: [kickedEmbed] });
                        return [4 /*yield*/, interaction.reply({
                                content: "Done. Kicked ".concat(user.tag),
                                ephemeral: true
                            })];
                    case 5:
                        _a.sent();
                        return [3 /*break*/, 27];
                    case 6:
                        if (!(interaction.options.getSubcommand() === 'clear')) return [3 /*break*/, 13];
                        channel = interaction.channel, options = interaction.options;
                        Amount_1 = options.getInteger('amount');
                        Target_1 = options.getUser('target');
                        return [4 /*yield*/, channel.messages.fetch()];
                    case 7:
                        Messages = _a.sent();
                        Response_1 = new EmbedBuilder().setColor('#2F3136');
                        if (!Target_1) return [3 /*break*/, 10];
                        i_1 = 0;
                        filtered_1 = [];
                        return [4 /*yield*/, Messages];
                    case 8:
                        (_a.sent()).filter(function (m) {
                            if (m.author.id === Target_1.id && Amount_1 > i_1) {
                                filtered_1.push(m);
                                i_1++;
                            }
                        });
                        return [4 /*yield*/, channel.bulkDelete(filtered_1, true).then(function (messages) {
                                Response_1.setDescription("> **Cleared `".concat(messages.size, "`** **from ").concat(Target_1, "**."));
                                Response_1.setTitle("Cleared Messages");
                                Response_1.setFooter({
                                    text: '©2022 - 2023 | Reliable',
                                    ephemeral: true
                                });
                                interaction.reply({ embeds: [Response_1] });
                            })];
                    case 9:
                        _a.sent();
                        return [3 /*break*/, 12];
                    case 10:
                        if (Amount_1 > 100) {
                            interaction.reply({
                                content: "Amount must be less than or equal to 100",
                                ephemeral: true
                            });
                        }
                        return [4 /*yield*/, channel.bulkDelete(Amount_1, true).then(function (messages) {
                                Response_1.setTitle('Cleared Messages');
                                Response_1.setDescription("> **Cleared `".concat(messages.size, "`** **from this channel.**"));
                                Response_1.setFooter({ text: '©2022 - 2023 | Reliable' });
                                interaction.reply({ embeds: [Response_1], ephemeral: true });
                            })];
                    case 11:
                        _a.sent();
                        _a.label = 12;
                    case 12: return [3 /*break*/, 27];
                    case 13:
                        if (!(interaction.options.getSubcommand() === 'timeout')) return [3 /*break*/, 15];
                        channel = interaction.channel, options = interaction.options;
                        user = options.getUser('target');
                        reason = interaction.options.getString('reason');
                        time = interaction.options.getInteger('time');
                        return [4 /*yield*/, interaction.guild.members
                                .fetch(user.id)["catch"](console.error)];
                    case 14:
                        member = _a.sent();
                        if (!reason)
                            reason = 'No reason provided';
                        if (member.id === interaction.user.id) {
                            error_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot timeout yourself!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [error_embed] })];
                        }
                        if (member.id === interaction.client.user.id) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot timeout me!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (member.id === interaction.guild.ownerId) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot timeout the owner!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (interaction.member.roles.highest.position <
                            member.roles.highest.position) {
                            error2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot timeout a user who have higher role than you!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [error2_embed], ephemeral: true })];
                        }
                        if (client.user.roles.highest.position < member.roles.highest.position) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | I cannot timeout a user who have higher role than me!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        member
                            .timeout(time == null ? null : time * 60 * 1000, reason)["catch"](console.error);
                        timoutEMBED = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setTitle("Timeout")
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .setTimestamp()
                            .addFields({
                            name: '‣ Timeout to',
                            value: "**`".concat(user.tag, "`**"),
                            inline: true
                        }, {
                            name: '‣ Timeout By',
                            value: "**`".concat(interaction.user.tag, "`**"),
                            inline: true
                        }, {
                            name: '‣ Timeout Duration',
                            value: "**`".concat(time, "m`**"),
                            inline: true
                        }, {
                            name: '‣ Reason',
                            value: "**`".concat(reason, "`**"),
                            inline: true
                        });
                        interaction.reply({ embeds: [timoutEMBED], ephemeral: true });
                        return [3 /*break*/, 27];
                    case 15:
                        if (!(interaction.options.getSubcommand() === 'lock')) return [3 /*break*/, 16];
                        channel = interaction.options.getChannel('channel') || interaction.channel;
                        if (!channel
                            .permissionsFor(interaction.guild.roles.everyone)
                            .has('SendMessages')) {
                            err_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | Channel is already locked!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' })
                                .setTimestamp();
                            interaction.reply({ embeds: [err_embed], ephemeral: true });
                        }
                        channel.permissionOverwrites.create(channel.guild.roles.everyone, {
                            SendMessages: false,
                            AddReactions: false
                        });
                        lockedembed = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setTitle("Channel Locked")
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .setTimestamp()
                            .addFields({
                            name: 'Locked Information',
                            value: "**`\u2022` Channel**: ".concat(channel, "\n**`\u2022` Moderator**: <@").concat(interaction.user.id, ">"),
                            inline: false
                        });
                        interaction.reply({ embeds: [lockedembed] });
                        return [3 /*break*/, 27];
                    case 16:
                        if (!(interaction.options.getSubcommand() === 'unlock')) return [3 /*break*/, 17];
                        channel = interaction.options.getChannel('channel') || interaction.channel;
                        channel.permissionOverwrites.create(channel.guild.roles.everyone, {
                            SendMessages: true,
                            AddReactions: true
                        });
                        unlockedembed = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setTitle("Channel Unlocked")
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .setTimestamp()
                            .addFields({
                            name: 'Unlocked Information',
                            value: "**`\u2022` Channel**: ".concat(channel, "\n**`\u2022` Moderator**: <@").concat(interaction.user.id, ">"),
                            inline: false
                        });
                        interaction.reply({ embeds: [unlockedembed] });
                        return [3 /*break*/, 27];
                    case 17:
                        if (!(interaction.options.getSubcommand() === 'list-bans')) return [3 /*break*/, 19];
                        amount = 1;
                        fetchBans = interaction.guild.bans.fetch();
                        return [4 /*yield*/, fetchBans];
                    case 18:
                        bannedMembers = (_a.sent())
                            .map(function (member) {
                            return "**`(#".concat(amount++, ")`** **`").concat(member.user.username, "`** | (*").concat(member.user.id, "*) [`**").concat(member.user.tag, "**`]");
                        })
                            .join('\n');
                        bannedlist = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setTitle("List of Banned Users")
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .setTimestamp()
                            .addFields({
                            name: 'Total Banned People',
                            value: "**`".concat(amount - 1, "`**"),
                            inline: true
                        })
                            .setDescription("".concat(bannedMembers));
                        interaction.reply({ embeds: [bannedlist] });
                        return [3 /*break*/, 27];
                    case 19:
                        if (!(interaction.options.getSubcommand() === 'role-member-info')) return [3 /*break*/, 20];
                        role_1 = interaction.options.getRole('role');
                        membersWithRole = interaction.guild.members.cache
                            .filter(function (member) {
                            return member.roles.cache.find(function (r) { return r.name === role_1.name; });
                        })
                            .map(function (member) {
                            return member.user.username;
                        });
                        if (membersWithRole > 2048) {
                            err_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('> **Sorry, the role member list is too big!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.reply({ embeds: [err_embed], ephemeral: true });
                        }
                        rolemember = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setTitle("Role Member Info")
                            .addFields({
                            name: 'Role Name',
                            value: "**<@&".concat(role_1.id, ">** (`").concat(role_1.id, "`)"),
                            inline: true
                        }, {
                            name: 'User(s) in it',
                            value: ">>> ".concat(membersWithRole.join('\n') || '**`N/A`**'),
                            inline: false
                        })
                            .setFooter({ text: '©2022 - 2023 | Reliable' });
                        interaction.reply({ embeds: [rolemember], ephemeral: true });
                        return [3 /*break*/, 27];
                    case 20:
                        if (!(interaction.options.getSubcommand() === 'addrole')) return [3 /*break*/, 21];
                        role = interaction.options.getRole('role');
                        member = interaction.options.getMember('user');
                        if (member.id === interaction.client.user.id) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription("**<:reliable_wrong:1043155193077960764> | I can't add role to me!**")
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (member.id === interaction.guild.ownerId) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot add role the owner!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (interaction.member.roles.highest.position <
                            member.roles.highest.position) {
                            error2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot add role to a user who have higher role than you!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [error2_embed], ephemeral: true })];
                        }
                        if (client.user.roles.highest.position < member.roles.highest.position) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | I cannot add role to a user who have higher role than me!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (member.roles.cache.has(role.id)) {
                            err_embed4 = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | The mentioned user already has the role!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.reply({ embeds: [err_embed4], ephemeral: true });
                        }
                        else {
                            member.roles.add(role);
                            embed = new EmbedBuilder()
                                .setTitle('Role Added')
                                .addFields({
                                name: 'Role added by',
                                value: "<@".concat(interaction.user.id, ">")
                            }, {
                                name: 'Role added to',
                                value: "<@".concat(member.id, ">")
                            }, {
                                name: 'Role Information',
                                value: "**`\u2022` Role Name**: <@&".concat(role.id, ">    \n          **`\u2022` Role Color**: **`").concat(role.hexColor, "`**")
                            })
                                .setColor('#2F3136')
                                .setTimestamp()
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.reply({ embeds: [embed] });
                        }
                        return [3 /*break*/, 27];
                    case 21:
                        if (!(interaction.options.getSubcommand() === 'removerole')) return [3 /*break*/, 22];
                        role = interaction.options.getRole('role');
                        member = interaction.options.getMember('user');
                        guild = interaction.guild;
                        if (member.id === interaction.client.user.id) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription("**<:reliable_wrong:1043155193077960764> | I can't remove role from me!**")
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (member.id === interaction.guild.ownerId) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot remove role the owner!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (interaction.member.roles.highest.position <
                            member.roles.highest.position) {
                            error2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot remove role to a user who have higher role than you!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [error2_embed], ephemeral: true })];
                        }
                        if (client.user.roles.highest.position < member.roles.highest.position) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | I cannot remove a role from a user who have higher role than me!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (!member.roles.cache.has(role.id)) {
                            err_embed4 = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription("**<:reliable_wrong:1043155193077960764> | The mentioned user doesn't have the role!**")
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.reply({ embeds: [err_embed4], ephemeral: true });
                        }
                        else {
                            member.roles.remove(role);
                            embed = new EmbedBuilder()
                                .setTitle('Role Removed')
                                .addFields({
                                name: 'Role removed by',
                                value: "<@".concat(interaction.user.id, ">")
                            }, {
                                name: 'Role removed from',
                                value: "<@".concat(member.id, ">")
                            }, {
                                name: 'Role Information',
                                value: "**`\u2022` Role Name**: <@&".concat(role.id, ">    \n      **`\u2022` Role Color**: **`").concat(role.hexColor, "`**")
                            })
                                .setColor('#2F3136')
                                .setTimestamp()
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.reply({ embeds: [embed] });
                        }
                        return [3 /*break*/, 27];
                    case 22:
                        if (!(interaction.options.getSubcommand() === 'setnick')) return [3 /*break*/, 26];
                        nickname = interaction.options.getString('nickname');
                        member = interaction.options.getMember('user');
                        if (member.id === interaction.client.user.id) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription("**<:reliable_wrong:1043155193077960764> | I can't set nick to me!**")
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (member.id === interaction.guild.ownerId) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot set nick to the owner!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (interaction.member.roles.highest.position <
                            member.roles.highest.position) {
                            error2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | You cannot set nick to a user who have higher role than you!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [error2_embed], ephemeral: true })];
                        }
                        if (client.user.roles.highest.position < member.roles.highest.position) {
                            err2_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | I cannot set nick to a user who have higher role than me!**')
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return [2 /*return*/, interaction.reply({ embeds: [err2_embed], ephemeral: true })];
                        }
                        if (!(nickname.length > 32)) return [3 /*break*/, 23];
                        err_embed4 = new EmbedBuilder()
                            .setTitle('Error')
                            .setDescription('**<:reliable_wrong:1043155193077960764> | The provided nickname is big! try small ones.**')
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' });
                        interaction.reply({ embeds: [err_embed4], ephemeral: true });
                        return [3 /*break*/, 25];
                    case 23:
                        oldNickname = member.nickname || 'None';
                        return [4 /*yield*/, member.setNickname(nickname)];
                    case 24:
                        _a.sent();
                        embed = new EmbedBuilder()
                            .setTitle('Nickname Changed')
                            .addFields({
                            name: 'Nick added by',
                            value: "<@".concat(interaction.user.id, ">")
                        }, {
                            name: 'Nick added to',
                            value: "<@".concat(member.id, ">")
                        }, {
                            name: 'Nick Information',
                            value: "**`\u2022` Old Nick**: **`".concat(oldNickname, "`**    \n      **`\u2022` New Nick**: **`").concat(nickname, "`**")
                        })
                            .setColor('#2F3136')
                            .setTimestamp()
                            .setFooter({ text: '©2022 - 2023 | Reliable' });
                        interaction.reply({ embeds: [embed] });
                        _a.label = 25;
                    case 25: return [3 /*break*/, 27];
                    case 26:
                        interaction.reply({ content: 'No sub command choosed' });
                        _a.label = 27;
                    case 27: return [2 /*return*/];
                }
            });
        });
    }
};
/**
 * @Author Reliable Inc.
 * @Copyright ©2022 - 2023 | Reliable Inc, All rights reserved.
 * @CodedBy Mohtasim Alam Sohom, Sajidur Rahman Tahsin
 */
//# sourceMappingURL=mod.js.map