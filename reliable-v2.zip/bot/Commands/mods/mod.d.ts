export let beta: boolean;
export let data: import("@discordjs/builders").SlashCommandSubcommandsOnlyBuilder;
export function execute(interaction: any, client: any): Promise<any>;
//# sourceMappingURL=mod.d.ts.map