export {};
//# sourceMappingURL=remove.d.ts.map