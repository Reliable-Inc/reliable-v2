import { SlashCommandBuilder } from "@discordjs/builders";
import { ChatInputCommandInteraction } from "discord.js";
import { Client } from "discord.js";
export let beta: boolean;
export let data: Omit<SlashCommandBuilder, "addSubcommandGroup" | "addSubcommand">;
/**
 * Execute the "say" command.
 * @param {ChatInputCommandInteraction} interaction The interaction instance.
 * @param {Client} client The client instance.
 */
export function execute(interaction: ChatInputCommandInteraction<import("discord.js").CacheType>, client: Client<boolean>): Promise<import("discord.js").Message<boolean> | undefined>;
//# sourceMappingURL=say.d.ts.map