import { ContextMenuCommandBuilder } from "@discordjs/builders";
export let developer: boolean;
export let data: ContextMenuCommandBuilder;
export function execute(interaction: any, client: any): Promise<void>;
//# sourceMappingURL=context.d.ts.map