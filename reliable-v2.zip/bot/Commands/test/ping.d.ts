import { SlashCommandBuilder } from "@discordjs/builders";
import { Client } from "discord.js";
export let developer: boolean;
export let data: SlashCommandBuilder;
/**
 *
 * @param {ChatInputCommandInteraction} interaction
 * @param {Client} client
 */
export function execute(interaction: ChatInputCommandInteraction, client: Client<boolean>): Promise<void>;
//# sourceMappingURL=ping.d.ts.map