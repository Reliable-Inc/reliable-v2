import { SlashCommandBuilder } from "@discordjs/builders";
export let developer: boolean;
export let data: SlashCommandBuilder;
/**
 *
 * @param {ChatInputCommandInteraction} interaction
 * @param {Client} client
 */
export function execute(interaction: ChatInputCommandInteraction, client: Client): Promise<void>;
//# sourceMappingURL=menu.d.ts.map