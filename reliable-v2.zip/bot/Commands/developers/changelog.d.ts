import { SlashCommandBuilder } from "@discordjs/builders";
export let data: SlashCommandBuilder;
export function execute(interaction: any, client: any): Promise<any>;
//# sourceMappingURL=changelog.d.ts.map