export {};
//# sourceMappingURL=apply-beta.d.ts.map