export {};
//# sourceMappingURL=beta.d.ts.map