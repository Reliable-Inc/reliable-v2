"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require('discord.js'), ContextMenuCommandBuilder = _a.ContextMenuCommandBuilder, ApplicationCommandType = _a.ApplicationCommandType, EmbedBuilder = _a.EmbedBuilder, ButtonBuilder = _a.ButtonBuilder, ActionRowBuilder = _a.ActionRowBuilder, ButtonStyle = _a.ButtonStyle;
var colors = require('discordjs-colors-bundle').colors;
var axios = require("axios");
module.exports = {
    developer: true,
    data: new ContextMenuCommandBuilder()
        .setName('user info')
        .setType(ApplicationCommandType.User),
    execute: function (interaction, client) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var guild, target, user, presence, roles, formatter, statusType, activityType, clientType, flags, maxDisplayRoles, response, data, sortedRoles, clientStatus, userFlags, badges, badges2, deviceFilter, devices, embed, avatarbutton;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, interaction.deferReply({ ephemeral: true })];
                    case 1:
                        _b.sent();
                        guild = client.guilds.cache.get(interaction.guild.id);
                        target = (_a = guild.members.cache.get(interaction.targetUser.id)) !== null && _a !== void 0 ? _a : interaction.member;
                        user = target.user, presence = target.presence, roles = target.roles;
                        formatter = new Intl.ListFormat('en-GB', {
                            style: 'narrow',
                            type: 'conjunction'
                        });
                        statusType = {
                            idle: '1FJj7pX.png',
                            dnd: 'fbLqSYv.png',
                            online: 'JhW7v9d.png',
                            invisible: 'dibKqth.png'
                        };
                        activityType = [
                            '🕹 Playing',
                            '🎙 Streaming',
                            '🎧 Listening to',
                            '📺 Watching',
                            '🤹🏻‍♀️ Custom',
                            '🏆 Competing in',
                        ];
                        clientType = [
                            { name: 'desktop', text: 'Computer', emoji: '💻' },
                            { name: 'mobile', text: 'Phone', emoji: '📱' },
                            { name: 'web', text: 'Website', emoji: '🔌' },
                            { name: 'offline', text: 'Offline', emoji: '💤' },
                        ];
                        flags = {
                            BugHunterLevel1: '<:reliable_bughunter:1030800879680507954 [**`Bug Hunter Level 1`**]',
                            BugHunterLevel2: '<:reliable_bughunter2:1030800967207243836 [**`Bug Hunter Level 2`**]',
                            CertifiedModerator: '<:reliable_moderation:1030443113958875236> [**`Certified Moderator`**]',
                            HypeSquadOnlineHouse1: '<:reliable_hypersquadbravery:1030801385706500150> [**`HyperSquad Bravery`**]',
                            HypeSquadOnlineHouse2: '<:reliable_hypesquadbrilliance:1030800522787176448> [**`HyperSquad Brilliance`**]',
                            HypeSquadOnlineHouse3: '<:reliable_hypersquadbalance:1030801362126114910> [**`HyperSquad Balance`**]',
                            Hypesquad: '<:reliable_hypesquadbrilliance:1030800522787176448>  [**`HyperSquad Brilliance`**]',
                            Partner: '<:reliable_discordparthner:1030801628741247066> [**`Discord Parthner`**]',
                            PremiumEarlySupporter: '<:reliable_earlysupporter:1030801808400056421>  [**`Early Supporter`**]',
                            Staff: '<:reliable_DiscordStaff:1030802121945260042> [**`Discord Staff`**]',
                            VerifiedBot: '<:reliable_verifedbot:1030802332298006598> [**`Verified Bot`**]',
                            ActiveDeveloper: '<:reliable_activedeveloper:1040628618344288286> [**`Active Developer`**]',
                            VerifiedDeveloper: '<a:reliable_developer:1030802329139675156> [**`Verified Developer`**]',
                            NITRO: '<:reliable_nitro:1053162461529911396> [**`Nitro`**]',
                            BOOSTER_1: '<:reliable_boost1:1053162540965826592> [**`Booster Level 1`**]',
                            BOOSTER_2: '<:reliable_boost2:1053163733347745823> [**`Booster Level 2`**]',
                            BOOSTER_3: '<:reliable_boost3:1053163885907157074> [**`Booster Level 3`**]',
                            BOOSTER_4: '<:reliable_boost4:1053164843202515036> [**`Booster Level 4`**]',
                            BOOSTER_5: '<:reliable_boost5:1053163087865331744> [**`Booster Level 5`**]',
                            BOOSTER_6: '<:reliable_boost6:1053162620292694077> [**`Booster Level 6`**]',
                            BOOSTER_7: '<:reliable_boost7:1053162572527972462> [**`Booster Level 7`**]',
                            BOOSTER_8: '<:reliable_boost8:1053162854687182858> [**`Booster Level 8`**]',
                            BOOSTER_9: '<:reliable_boost9:1053162671056363531> [**`Booster Level 9`**]'
                        };
                        maxDisplayRoles = function (roles, maxFieldLength) {
                            if (maxFieldLength === void 0) { maxFieldLength = 1024; }
                            var totalLength = 0;
                            var result = [];
                            for (var _i = 0, roles_1 = roles; _i < roles_1.length; _i++) {
                                var role = roles_1[_i];
                                var roleString = "<@&".concat(role.id, ">");
                                if (roleString.length + totalLength > maxFieldLength)
                                    break;
                                totalLength += roleString.length + 1; // +1 as it's likely we want to display them with a space between each role, which counts towards the limit.
                                result.push(roleString);
                            }
                            return result.length;
                        };
                        return [4 /*yield*/, axios.get("https://japi.rest/discord/v1/user/".concat(target))];
                    case 2:
                        response = _b.sent();
                        data = response;
                        sortedRoles = roles.cache
                            .map(function (role) { return role; })
                            .sort(function (a, b) { return b.position - a.position; })
                            .slice(0, roles.cache.size - 1);
                        clientStatus = (presence === null || presence === void 0 ? void 0 : presence.clientStatus) instanceof Object
                            ? Object.keys(presence.clientStatus)
                            : 'offline';
                        userFlags = user.flags.toArray();
                        badges = data.data.public_flags_array
                            ? data.data.public_flags_array.map(function (flag) { return flags[flag]; }).join(' ')
                            : 'No Badges.';
                        badges2 = userFlags.length
                            ? formatter.format(userFlags.map(function (flag) { return "**".concat(flags[flag], "**"); }))
                            : '**`None`**';
                        deviceFilter = clientType.filter(function (device) {
                            return clientStatus.includes(device.name);
                        });
                        devices = !Array.isArray(deviceFilter)
                            ? new Array(deviceFilter)
                            : deviceFilter;
                        embed = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .setAuthor({
                            name: user.tag,
                            iconURL: "https://i.imgur.com/".concat(statusType[(presence === null || presence === void 0 ? void 0 : presence.status) || 'invisible'])
                        })
                            .setImage(user.bannerURL({ size: 1024 }))
                            .addFields({ name: '`🆔` | ID', value: "**`".concat(user.id, "`**") }, {
                            name: ' `⭐` | Activities',
                            value: (presence === null || presence === void 0 ? void 0 : presence.activities.map(function (activity) {
                                return "` ".concat(activityType[activity.type], " ").concat(activity.name, " ` ");
                            }).join('\n')) || '**`None`**'
                        }, {
                            name: ' `📆` | Account Created',
                            value: "<t:".concat(parseInt(user.createdTimestamp / 1000), ":R>"),
                            inline: true
                        }, {
                            name: '`🤝🏻` | Joined Server',
                            value: "<t:".concat(parseInt(target.joinedTimestamp / 1000), ":R>"),
                            inline: true
                        }, {
                            name: ' `🦸🏻‍♀️` | Nickname',
                            value: "**".concat(user.nickname || '**`None`**', "**"),
                            inline: true
                        }, {
                            name: "`\uD83C\uDF42` | Roles (".concat(maxDisplayRoles(sortedRoles), " of ").concat(sortedRoles.length, ")"),
                            value: "".concat(sortedRoles.slice(0, maxDisplayRoles(sortedRoles)).join(' ') ||
                                '**`None`**')
                        }, {
                            name: "`\uD83C\uDF8B` | Badges",
                            value: "".concat(badges, " ").concat(badges2)
                        }, {
                            name: "`\uD83C\uDF80` | Devices",
                            value: devices
                                .map(function (device) { return "**`".concat(device.emoji, " ").concat(device.text, "`**"); })
                                .join('\n'),
                            inline: true
                        }, {
                            name: ' `🖤` | Boosting Server',
                            value: "".concat(roles.premiumSubscriberRole
                                ? "**`Since`** <t:".concat(parseInt(target.premiumSinceTimestamp / 1000), ":R>")
                                : '**`No`**'),
                            inline: true
                        }, {
                            name: ' `🎏` | Banner',
                            value: user.bannerURL() ? '** **' : '**`None`**'
                        });
                        avatarbutton = new ButtonBuilder()
                            .setLabel("Avatar Link")
                            .setEmoji('<:reliable_earlysupporter:1030801808400056421>')
                            .setStyle(ButtonStyle.Link)
                            .setURL("".concat(user.avatarURL({ size: 1024, dynamic: true, extension: 'png' }) ||
                            'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/75bff394-4f86-45a8-a923-e26223aa74cb/de901o7-d61b3bfb-f1b1-453b-8268-9200130bbc65.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzc1YmZmMzk0LTRmODYtNDVhOC1hOTIzLWUyNjIyM2FhNzRjYlwvZGU5MDFvNy1kNjFiM2JmYi1mMWIxLTQ1M2ItODI2OC05MjAwMTMwYmJjNjUucG5nIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.aEck9OnRf_XJzrEzZNvrGS2XpAlo2ixuxoAX5fgpNnw'));
                        return [2 /*return*/, interaction.editReply({
                                embeds: [embed],
                                components: [new ActionRowBuilder().addComponents(avatarbutton)],
                                ephemeral: false
                            })];
                }
            });
        });
    }
};
//# sourceMappingURL=context.info.js.map