import { ContextMenuCommandBuilder } from "@discordjs/builders";
export let developer: boolean;
export let data: ContextMenuCommandBuilder;
export function execute(interaction: any, client: any): Promise<any>;
//# sourceMappingURL=context.info.d.ts.map