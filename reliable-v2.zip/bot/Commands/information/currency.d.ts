import { SlashCommandBuilder } from "@discordjs/builders";
import { ChatInputCommandInteraction } from "discord.js";
import { Client } from "discord.js";
export let developer: boolean;
export let data: SlashCommandBuilder;
/**
 *
 * @param {ChatInputCommandInteraction} interaction
 * @param {Client} client
 */
export function execute(interaction: ChatInputCommandInteraction<import("discord.js").CacheType>, client: Client<boolean>): Promise<void>;
//# sourceMappingURL=currency.d.ts.map