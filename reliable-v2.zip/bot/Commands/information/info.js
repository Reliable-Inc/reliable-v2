"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require('discord.js'), SlashCommandBuilder = _a.SlashCommandBuilder, ChatInputCommandInteraction = _a.ChatInputCommandInteraction, ButtonBuilder = _a.ButtonBuilder, ButtonStyle = _a.ButtonStyle, EmbedBuilder = _a.EmbedBuilder, ChannelType = _a.ChannelType, GuildVerificationLevel = _a.GuildVerificationLevel, GuildExplicitContentFilter = _a.GuildExplicitContentFilter, GuildNSFWLevel = _a.GuildNSFWLevel, Embed = _a.Embed, ActionRowBuilder = _a.ActionRowBuilder;
var _b = require('discordjs-colors-bundle'), CustomHex = _b.CustomHex, CustomRGB = _b.CustomRGB;
var moment = require('moment');
var axios = require('axios');
var twitter = require('twitter-api.js');
var translate = require('@iamtraction/google-translate');
var imdb = require('imdb-api');
var mal = require('mal-scraper');
var json = require('stream/consumers').json;
module.exports = {
    beta: false,
    data: new SlashCommandBuilder()
        .setName('info')
        .setDescription('info command')
        .addSubcommand(function (sub) {
        return sub
            .setName('anime')
            .setDescription('💮 Search for information about Anime by given name')
            .addStringOption(function (option) {
            return option.setName('query').setDescription('Anime name').setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('channel')
            .setDescription('View ℹ️ info about a 📺 channel.')
            .addChannelOption(function (option) {
            return option
                .setName('channel')
                .setDescription('Mention the channel')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('movie')
            .setDescription('View ℹ️ info about a 🎥 movie.')
            .addStringOption(function (option) {
            return option
                .setName('name')
                .setDescription('Name of the movie')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('covid')
            .setDescription("Track 🌍 a country's COVID-19 cases 📊")
            .addStringOption(function (op) {
            return op
                .setName('country')
                .setDescription('Provide a country')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('country')
            .setDescription('Get ℹ️ information about a 🌍 country.')
            .addStringOption(function (op) {
            return op.setName('name').setDescription('Country name').setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('member-count')
            .setDescription('see the total members of your server');
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('npm')
            .setDescription('Check for packages on npm')
            .addStringOption(function (op) {
            return op
                .setName('name')
                .setDescription('Provide a name to request content from.')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('pokemon')
            .setDescription('Returns pokemon information')
            .addStringOption(function (op) {
            return op
                .setName('name')
                .setDescription('Provide a name to request content from.')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('reddit')
            .setDescription('Request random content from Reddit via subreddits.')
            .addStringOption(function (op) {
            return op
                .setName('subreddit')
                .setDescription('Provide a subreddit to request content from.')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('role')
            .setDescription('View info about a role')
            .addRoleOption(function (option) {
            return option
                .setName('role')
                .setDescription('The role to view info of')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('translate')
            .setDescription('Translate any word/sentence to EN')
            .addStringOption(function (option) {
            return option
                .setName('query')
                .setDescription('The text to translate')
                .setRequired(true);
        })
            .addStringOption(function (option) {
            return option
                .setName('from')
                .setDescription('Source Language.')
                .setRequired(true);
        })
            .addStringOption(function (option) {
            return option
                .setName('to')
                .setDescription('Destination Language.')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('role-perm')
            .setDescription('Shows a role permissions')
            .addRoleOption(function (op) {
            return op
                .setName('target')
                .setDescription('Select the target')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('weather')
            .setDescription('get weather information')
            .addStringOption(function (op) {
            return op
                .setName('place')
                .setDescription('country/city name to get weather information for')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub.setName('apod').setDescription('Astronomy Picture of the Day');
    })
        .addSubcommand(function (sub) {
        return sub.setName('quotes').setDescription('Sends random quotes');
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('server')
            .setDescription('Displays information about the server.');
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('user')
            .setDescription('get user info')
            .addUserOption(function (op) {
            return op
                .setName('target')
                .setDescription('Select the target')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('user-perm')
            .setDescription("Shows a user's permissions")
            .addUserOption(function (op) {
            return op
                .setName('target')
                .setDescription('Select the target')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('twitter')
            .setDescription('Shows a twitter account information')
            .addStringOption(function (op) {
            return op
                .setName('account')
                .setDescription('Mention the account name')
                .setRequired(true);
        });
    })
        .addSubcommand(function (sub) {
        return sub.setName('space').setDescription('Shows latest space informations.');
    }),
    /**
     *
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     * @returns
     */
    execute: function (interaction, client) {
        var _a, _b, _c, _d, _e;
        return __awaiter(this, void 0, void 0, function () {
            var search, channel, webhooks, webhookArray, vcmember, memberArray, channeltype, embed, components, countries, members, dndusers, onlineusers2, onlineusers3, dndbots, onlinebots2, onlinebots3, usersonlineAll, botssonlineAll, embed, target, poke2_1, subreddit, embed, reactions, response, reply_1, error_1, role, displayed, mentionable, createdts, createdtime, embed, role, rolePermissions, embed, guild, members, channels_1, emojis, roles, stickers, sortedRoles, userRoles, managedRoles, botCount, maxDisplayRoles, splitPascal_1, toPascalCase_1, getChannelTypeSize, totalChannels, target, user, presence, roles, formatter, statusType, activityType_1, clientType, flags_1, maxDisplayRoles, response, data, sortedRoles, clientStatus_1, userFlags, badges, badges2, deviceFilter, devices, embed, avatarbutton, member, memberPermissions, embed, query, raw, from, to, translated, Embed_1, err_1, err_embed, user, body, verifiedtweet, tweet, e_1, err_embed, err_embed2, imob, movie, Embed_2, err_embed, country, err_embed, place, err_embed, country, err_embed;
            return __generator(this, function (_f) {
                switch (_f.label) {
                    case 0: return [4 /*yield*/, interaction.deferReply({ ephemeral: true })];
                    case 1:
                        _f.sent();
                        if (!(interaction.options.getSubcommand() == 'anime')) return [3 /*break*/, 2];
                        search = interaction.options.getString('query');
                        mal.getInfoFromName(search).then(function (data) {
                            if (data.rating == 'Rx - Hentai' && !interaction.channel.nsfw) {
                                var embed2 = new EmbedBuilder()
                                    .setTitle('🔞 | NSFW content')
                                    .setColor(CustomHex('#2F3136'))
                                    .setTimestamp()
                                    .setFooter({ text: '©2022 - 2023 | Reliable' })
                                    .setDescription('> **<:reliable_wrong:1043155193077960764> | No `Age-Restricted` content allowed in this channel. Go to a channel where `NSFW` is enabled.**');
                                return interaction.editReply({ embeds: [embed2], ephemeral: true });
                            }
                            else {
                                var embed = new EmbedBuilder()
                                    .setTitle("".concat(data.title))
                                    .setDescription("```".concat(data.synopsis || 'N/A', "```"))
                                    .setImage(data.picture)
                                    .setColor(CustomHex('#2F3136'))
                                    .addFields({
                                    name: '__Titles:__',
                                    value: "**`\u2022` English**: **`".concat(data.englishTitle || 'N/A', "`**\n**`\u2022` Japanese**: **`").concat(data.japaneseTitle || 'N/A', "`**"),
                                    inline: false
                                }, {
                                    name: '__Rank & Popularity:__',
                                    value: "**`\u2022` Rank**: **`".concat(data.ranked || 'N/A', "`**\n**`\u2022` Popularity**: **`").concat(data.popularity || 'N/A', "`**"),
                                    inline: false
                                }, {
                                    name: '__Aired & Broadcast:__',
                                    value: "**`\u2022`Aired**: **`".concat(data.aired || 'N/A', "`**\n**`\u2022` Broadcast Every**: **`").concat(data.broadcast || 'N/A', "`**"),
                                    inline: false
                                }, {
                                    name: '__Members & Favorites:__',
                                    value: "**`\u2022`Members**: **`".concat(data.members || 'N/A', "`**\n**`\u2022`Favorites**: **`").concat(data.favorites || 'N/A', "`**"),
                                    inline: true
                                }, {
                                    name: '__Episodes & Durations:__',
                                    value: "**`\u2022`Episodes**: **`".concat(data.episodes || 'N/A', "`**\n**`\u2022`Duration Per Episode**: **`").concat(data.duration || 'N/A', "`**"),
                                    inline: true
                                }, {
                                    name: '__Source & Ratings:__',
                                    value: "**`\u2022`Source**: **`".concat(data.source || 'N/A', "`**\n**`\u2022`Ratings**: **`").concat(data.rating || 'N/A', "`**"),
                                    inline: true
                                }, {
                                    name: '__Score & Score Stats:__',
                                    value: "**`\u2022`Score**: **`".concat(data.score || 'N/A', "`**\n**`\u2022`Score Stats**: **`").concat(data.scoreStats || 'N/A', "`**"),
                                    inline: true
                                }, {
                                    name: '__Studios & Synonyms__',
                                    value: "**`\u2022`Studios**: **`".concat(data.studios || 'N/A', "`**\n**`\u2022`Synonyms**: **`").concat(data.synonyms || 'N/A', "`**"),
                                    inline: true
                                }, {
                                    name: '__Status__',
                                    value: "**`\u2022`Status**: **`".concat(data.status || 'N/A', "`**"),
                                    inline: true
                                }, {
                                    name: '__Identifier & Type__',
                                    value: "**`\u2022`Identifier**: **`".concat(data.id || 'N/A', "`**\n**`\u2022`Type**: **`").concat(data.type || 'N/A', "`**"),
                                    inline: true
                                }, {
                                    name: '__Characters & Roles:__',
                                    value: "```".concat(data.characters
                                        ? data.characters
                                            .map(function (x) { return "".concat(x.name, ": ").concat(x.role); })
                                            .join('\n')
                                        : 'N/A', "```"),
                                    inline: true
                                }, {
                                    name: '__Staff & Role:__',
                                    value: "```".concat(data.staff
                                        ? data.staff.map(function (x) { return "".concat(x.name, ": ").concat(x.role); }).join('\n')
                                        : 'N/A', "```"),
                                    inline: true
                                }, {
                                    name: '__Producers:__',
                                    value: "```".concat(data.producers ? data.producers.join('\n') : 'N/A', "```"),
                                    inline: true
                                })
                                    .setFooter({ text: '©2022 - 2023 | Reliable' })
                                    .setTimestamp();
                                var row = new ActionRowBuilder().addComponents(new ButtonBuilder()
                                    .setStyle(ButtonStyle.Link)
                                    .setURL(data.url)
                                    .setLabel('View more about this'));
                                interaction.editReply({ embeds: [embed], components: [row] });
                            }
                        });
                        return [3 /*break*/, 41];
                    case 2:
                        if (!(interaction.options.getSubcommand() === 'channel')) return [3 /*break*/, 4];
                        channel = interaction.options.getChannel('channel') || interaction.channel;
                        return [4 /*yield*/, channel.fetchWebhooks()];
                    case 3:
                        webhooks = _f.sent();
                        webhookArray = webhooks.size;
                        vcmember = channel.members;
                        memberArray = vcmember.size;
                        channeltype = 'Text Channel';
                        if (channel.type === 15) {
                            channeltype = 'Forum';
                        }
                        if (channel.type === 0) {
                            channeltype = 'Text';
                        }
                        if (channel.type === 1) {
                            channeltype = 'DM';
                        }
                        if (channel.type === 2) {
                            channeltype = 'Voice';
                        }
                        if (channel.type === 3) {
                            channeltype = 'Group DM';
                        }
                        if (channel.type === 4) {
                            channeltype = 'Category';
                        }
                        if (channel.type === 5) {
                            channeltype = 'Announcement';
                        }
                        if (channel.type === 10) {
                            channeltype = 'Text';
                        }
                        if (channel.type === 11) {
                            channeltype = 'Text';
                        }
                        if (channel.type === 12) {
                            channeltype = 'Text';
                        }
                        if (channel.type === 13) {
                            channeltype = 'Text';
                        }
                        if (channel.type === 14) {
                            channeltype = 'Text';
                        }
                        embed = new EmbedBuilder()
                            .setTitle("__Channel Information__")
                            .setDescription("".concat(channel.topic ||
                            'No topic found about this channel! Consider adding one.'))
                            .setFooter({ text: 'Reliable | Your trusted assistant' })
                            .addFields({
                            name: '__Channel Details__',
                            value: "**`\u00BB` Name**: ".concat(channel, "\n**`\u00BB` ID**: `").concat(channel.id, "`\n**`\u00BB` Category**: `").concat(channel.parentId ? "".concat(channel.parent.name) : 'None', "`\n**`\u00BB` Total Webhooks**: `").concat(webhookArray || 'None', "`\n**`\u00BB` Created**: <t:").concat(parseInt(channel.createdTimestamp / 1000), ":R>"),
                            inline: false
                        }, {
                            name: '__Voice Channel__',
                            value: "**`\u2022` Members**: `".concat(memberArray || 'None', "`\n**`\u2022` Max Members**: `").concat(channel.userLimit || 'None', "`\n**`\u2022` Bitrate**: `").concat(channel.bitrate || 'None', "`")
                        })
                            .setColor(CustomHex('#2F3136'));
                        components = new ActionRowBuilder().addComponents(new ButtonBuilder()
                            .setCustomId('YES')
                            .setLabel("Position: ".concat(channel.position))
                            .setStyle('Secondary')
                            .setDisabled(true), new ButtonBuilder()
                            .setCustomId('NO')
                            .setLabel("Type: ".concat(channeltype))
                            .setStyle('Secondary')
                            .setDisabled(true), new ButtonBuilder()
                            .setCustomId('idk')
                            .setLabel("NSFW: ".concat(channel.nsfw ? 'Yes' : 'No'))
                            .setStyle('Secondary')
                            .setDisabled(true));
                        interaction.editReply({ embeds: [embed], components: [components] });
                        return [3 /*break*/, 41];
                    case 4:
                        if (!(interaction.options.getSubcommand() === 'covid')) return [3 /*break*/, 5];
                        countries = interaction.options.getString('country');
                        axios
                            .get("https://disease.sh/v2/countries/".concat(countries))
                            .then(function (response) { return response.data; })
                            .then(function (data) {
                            var embed = new EmbedBuilder()
                                .setTitle("__Coronavirus__")
                                .setDescription("Coronavirus disease (COVID-19) is an infectious disease caused by the SARS-CoV-2 virus. Coronavirus disease (COVID-19) is an infectious disease caused by the SARS-CoV-2 virus.\nMost people who fall sick with COVID-19 will experience mild to moderate symptoms and recover without special treatment. However, some will become seriously ill and require medical attention.")
                                .setColor(CustomHex('#2F3136'))
                                .setFooter({ text: 'Reliable | Your trusted assistant' })
                                .setThumbnail(data === null || data === void 0 ? void 0 : data.countryInfo.flag)
                                .addFields({
                                name: '__Information__',
                                value: "**`\u00BB` Cases Total**: `".concat(data === null || data === void 0 ? void 0 : data.cases.toString(), "`\n**`\u00BB` Cases Today**: `").concat(data === null || data === void 0 ? void 0 : data.todayCases.toString(), "`\n**`\u00BB` Deaths Total**: `").concat(data === null || data === void 0 ? void 0 : data.deaths.toString(), "`\n**`\u00BB` Deaths Today**: `").concat(data === null || data === void 0 ? void 0 : data.todayDeaths.toString(), "`\n**`\u00BB` Recovered**: `").concat(data === null || data === void 0 ? void 0 : data.recovered.toString(), "`\n**`\u00BB` Active**: `").concat(data === null || data === void 0 ? void 0 : data.active.toString(), "`\n**`\u00BB` Critical**: `").concat(data === null || data === void 0 ? void 0 : data.critical.toString(), "`\n**`\u00BB` Cases per 1 million**: `").concat(data === null || data === void 0 ? void 0 : data.casesPerOneMillion.toString(), "`\n**`\u00BB` Deaths per 1 million**: `").concat(data === null || data === void 0 ? void 0 : data.deathsPerOneMillion.toString(), "`\n**`\u00BB` Recovered per 1 million**: `").concat(data === null || data === void 0 ? void 0 : data.recoveredPerOneMillion.toString(), "`\n                "),
                                inline: false
                            });
                            var components = new ActionRowBuilder().addComponents(new ButtonBuilder()
                                .setCustomId('YES')
                                .setLabel("Country Name: ".concat(data.country))
                                .setStyle('Secondary')
                                .setDisabled(true), new ButtonBuilder()
                                .setCustomId('NO')
                                .setLabel("Lat & Lon: ".concat(data === null || data === void 0 ? void 0 : data.countryInfo.lat, " & ").concat(data === null || data === void 0 ? void 0 : data.countryInfo.long))
                                .setStyle('Secondary')
                                .setDisabled(true), new ButtonBuilder()
                                .setCustomId('idk')
                                .setLabel("Population: ".concat(data === null || data === void 0 ? void 0 : data.population.toString()))
                                .setStyle('Secondary')
                                .setDisabled(true), new ButtonBuilder()
                                .setCustomId('idkh')
                                .setLabel("Continent: ".concat(data === null || data === void 0 ? void 0 : data.continent.toString()))
                                .setStyle('Secondary')
                                .setDisabled(true));
                            interaction.editReply({ embeds: [embed], components: [components] });
                        })["catch"](function (e) {
                            console.log(e);
                            var Embed = new EmbedBuilder()
                                .setTitle('Error | 500 Internal Server')
                                .setColor("#2F3136")
                                .addFields({
                                name: '<:reliable_offline:1040907697853321366> | __Found__',
                                value: '```' + e + '```'
                            })
                                .setFooter({ text: 'Reliable | Your trusted assistant.' })
                                .setDescription("<:reliable_dnd:1044914867779412078> | The server encountered an unexpected condition that prevented it from fulfilling the request. It is an internal error on the server side, typically caused by misconfigurations, software bugs, or server overload. Users should contact the server administrator for resolution.");
                            interaction.editReply({ embeds: [Embed], ephemeral: true });
                        });
                        return [3 /*break*/, 41];
                    case 5:
                        if (!(interaction.options.getSubcommand() === 'member-count')) return [3 /*break*/, 6];
                        members = interaction.guild.members.cache;
                        dndusers = members.filter(function (member) { var _a; return !member.user.bot && ((_a = member.presence) === null || _a === void 0 ? void 0 : _a.status) === 'dnd'; }).size;
                        onlineusers2 = members.filter(function (member) { var _a; return !member.user.bot && ((_a = member.presence) === null || _a === void 0 ? void 0 : _a.status) === 'online'; }).size;
                        onlineusers3 = members.filter(function (member) { var _a; return !member.user.bot && ((_a = member.presence) === null || _a === void 0 ? void 0 : _a.status) === 'idle'; }).size;
                        dndbots = members.filter(function (member) { var _a; return member.user.bot && ((_a = member.presence) === null || _a === void 0 ? void 0 : _a.status) === 'dnd'; }).size;
                        onlinebots2 = members.filter(function (member) { var _a; return member.user.bot && ((_a = member.presence) === null || _a === void 0 ? void 0 : _a.status) === 'online'; }).size;
                        onlinebots3 = members.filter(function (member) { var _a; return member.user.bot && ((_a = member.presence) === null || _a === void 0 ? void 0 : _a.status) === 'idle'; }).size;
                        usersonlineAll = dndusers + onlineusers2 + onlineusers3;
                        botssonlineAll = dndbots + onlinebots2 + onlinebots3;
                        embed = new EmbedBuilder()
                            .setColor(CustomHex('#2F3136'))
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .setTitle("Membercount")
                            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                            .addFields({
                            name: ":couple: Total Members (".concat(interaction.guild.memberCount, ")"),
                            value: "**`\u2022` Members: `".concat(members.filter(function (member) { return !member.user.bot; }).size, "`**\n**`\u2022` Bots: `").concat(members.filter(function (member) { return member.user.bot; }).size, "`**"),
                            inline: false
                        }, {
                            name: "<:reliable_verifedbot:1030802332298006598> Total Online Members (`".concat(usersonlineAll, "` / `").concat(members.filter(function (member) { return !member.user.bot; }).size, "`)"),
                            value: "**<:reliable_dnd:1044914867779412078> Users with DND: `".concat(dndusers, "`**\n**<:reliable_online:1040907077763207259> Users with Online: `").concat(onlineusers2, "`**\n**<:reliable_idle:1044914924519960606> Users with Idle: `").concat(onlineusers3, "`**"),
                            inline: false
                        }, {
                            name: "<:reliable_maintainance:1040906925233143878> Total Online Bots (`".concat(botssonlineAll, "` / `").concat(members.filter(function (member) { return member.user.bot; }).size, "`)"),
                            value: "**<:reliable_dnd:1044914867779412078> Bots with DND: `".concat(dndbots, "`**\n**<:reliable_online:1040907077763207259> Bots with Online: `").concat(onlinebots2, "`**\n**<:reliable_idle:1044914924519960606> Bots with Idle: `").concat(onlinebots3, "`**"),
                            inline: false
                        })
                            .setTimestamp();
                        interaction.editReply({ embeds: [embed] });
                        return [3 /*break*/, 41];
                    case 6:
                        if (!(interaction.options.getSubcommand() === 'npm')) return [3 /*break*/, 7];
                        target = interaction.options.getString('name') || '';
                        axios
                            .get("https://registry.npmjs.com/".concat(target))
                            .then(function (res) { return res.data; })
                            .then(function (json) {
                            var _a, _b, _c, _d, _e, _f;
                            var embed = new EmbedBuilder()
                                .setColor(CustomHex('#2F3136'))
                                .setTitle('__Searched__')
                                .setImage('https://www.bleepstatic.com/content/posts/2018/07/12/npm.png')
                                .setDescription(json.description ||
                                "I apologize, but you haven't provided any specific information about the npm package you would like a detailed and formal description for. In order to provide an accurate and relevant description, I would need to know the name or purpose of the npm package you are referring to. Please provide more details, and I'll be happy to assist you further.")
                                .addFields({
                                name: '__Information__',
                                value: "**`\u00BB` Maintainers**: `".concat(json.maintainers
                                    .map(function (user) { return user.name; })
                                    .join(', '), "`\n**`\u00BB` Engines**: `").concat((_b = (_a = json.engines) === null || _a === void 0 ? void 0 : _a.node) !== null && _b !== void 0 ? _b : "Doesn't have any specific engine.", "`\n**`\u00BB` Modification Date**: `").concat(((_c = json.time) === null || _c === void 0 ? void 0 : _c.modified)
                                    ? moment.utc(json.time.modified).format('YYYY/MM/DD hh:mm:ss')
                                    : 'N/A', "`"),
                                inline: false
                            });
                            var bcomponents = new ActionRowBuilder().addComponents(new ButtonBuilder()
                                .setCustomId('torbap')
                                .setLabel("Package Name: ".concat(json.name || 'N/A'))
                                .setStyle('Secondary')
                                .setDisabled(true), new ButtonBuilder()
                                .setCustomId('chudi')
                                .setLabel("Author: ".concat(((_d = json.author) === null || _d === void 0 ? void 0 : _d.name) || 'Unknown'))
                                .setStyle('Secondary')
                                .setDisabled(true), new ButtonBuilder()
                                .setCustomId('kutta')
                                .setLabel("Creation Date: ".concat(moment
                                .utc((_e = json.time) === null || _e === void 0 ? void 0 : _e.created)
                                .format('YYYY/MM/DD hh:mm:ss')))
                                .setStyle('Secondary')
                                .setDisabled(true), new ButtonBuilder()
                                .setCustomId('kuttachuda')
                                .setLabel("Version: ".concat(((_f = json['dist-tags']) === null || _f === void 0 ? void 0 : _f.latest) || 'N/A'))
                                .setStyle('Secondary')
                                .setDisabled(true));
                            return interaction.editReply({
                                embeds: [embed],
                                components: [bcomponents],
                                ephemeral: false
                            });
                        });
                        return [3 /*break*/, 41];
                    case 7:
                        if (!(interaction.options.getSubcommand() === 'pokemon')) return [3 /*break*/, 8];
                        poke2_1 = interaction.options.getString('name') || '';
                        axios
                            .get("https://some-random-api.ml/pokemon/pokedex?pokemon=".concat(poke2_1))
                            .then(function (res) { return res.data; })
                            .then(function (json) {
                            var embed = new EmbedBuilder()
                                .setTitle("".concat(json.name))
                                .setThumbnail("http://i.some-random-api.ml/pokemon/".concat(poke2_1, ".gif"))
                                .setDescription("> ".concat(json.description))
                                .addFields({
                                name: 'ID',
                                value: "> **`".concat(json.id, "`**")
                            }, {
                                name: 'Type',
                                value: "> **`".concat(json.type, "`**")
                            }, {
                                name: 'Species',
                                value: "> **`".concat(json.species, "`**")
                            }, {
                                name: 'Abilities',
                                value: "> **`".concat(json.abilities, "`**")
                            }, {
                                name: 'Height',
                                value: "> **`".concat(json.height, "`**")
                            }, {
                                name: 'Weight',
                                value: "> **`".concat(json.weight, "`**")
                            }, {
                                name: 'Base Experience',
                                value: "> **`".concat(json.base_experience, "`**")
                            }, {
                                name: 'Gender',
                                value: "> **`".concat(json.gender, "`**")
                            }, {
                                name: 'Egg Groups',
                                value: "> **`".concat(json.egg_groups, "`**")
                            }, {
                                name: 'Generation',
                                value: "> **`".concat(json.generation, "`**"),
                                inline: true
                            })
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            return interaction.editReply({ embeds: [embed] });
                        });
                        return [3 /*break*/, 41];
                    case 8:
                        if (!(interaction.options.getSubcommand() === 'reddit')) return [3 /*break*/, 14];
                        subreddit = interaction.options.getString('subreddit') || '';
                        embed = new EmbedBuilder().setColor(CustomRGB(255, 0, 0));
                        reactions = ['😂', '🤨'];
                        _f.label = 9;
                    case 9:
                        _f.trys.push([9, 12, , 13]);
                        return [4 /*yield*/, axios.get("https://meme-api.herokuapp.com/gimme/".concat(encodeURIComponent(subreddit)))];
                    case 10:
                        response = _f.sent();
                        if (((_a = response === null || response === void 0 ? void 0 : response.data) === null || _a === void 0 ? void 0 : _a.nsfw) && !interaction.channel.nsfw) {
                            embed
                                .setTitle('🔞 NSFW content')
                                .setDescription('No **Age-Restricted** content allowed in this channel. Go to a channel where **NSFW** is *enabled*.');
                            return [2 /*return*/, interaction.editReply({ embeds: [embed], ephemeral: true })];
                        }
                        embed
                            .setColor('#2F3136')
                            .setTitle('Reddit Searched')
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .addFields({
                            name: "\u2023 Reddit Title",
                            value: "> **`".concat(response.data.title, "`**"),
                            inline: false
                        }, {
                            name: "\u2023 Reddit URL",
                            value: "> **[Click here](".concat(response.data.postLink, ")**"),
                            inline: false
                        }, {
                            name: "\u2023 Reddit Rating",
                            value: "> **`".concat(response.data.ups, "`**"),
                            inline: false
                        }, {
                            name: "\u2023 Reddit By",
                            value: "> **[".concat(response.data.author, "](https://reddit.com/user/").concat(response.data.author, ")**"),
                            inline: false
                        })
                            .setImage(response.data.url);
                        return [4 /*yield*/, interaction.editReply({
                                embeds: [embed],
                                fetchReply: true
                            })];
                    case 11:
                        reply_1 = _f.sent();
                        reactions.forEach(function (reaction) { return reply_1.react(reaction)["catch"](function () { }); });
                        return [3 /*break*/, 13];
                    case 12:
                        error_1 = _f.sent();
                        embed
                            .setTitle('🔍 Unable to reach API')
                            .setDescription("A connection to the API could not be established.");
                        if ((_c = (_b = error_1.response) === null || _b === void 0 ? void 0 : _b.data) === null || _c === void 0 ? void 0 : _c.message)
                            embed
                                .setTitle('🔍 Unable to find content or subreddit')
                                .setDescription(error_1.response.data.message);
                        interaction.editReply({ embeds: [embed], ephemeral: true });
                        return [3 /*break*/, 13];
                    case 13: return [3 /*break*/, 41];
                    case 14:
                        if (!(interaction.options.getSubcommand() === 'role')) return [3 /*break*/, 16];
                        role = interaction.options.getRole('role');
                        displayed = role.hoist === true ? 'Yes' : 'No';
                        mentionable = role.mentionable === true ? 'Yes' : 'No';
                        createdts = new Date(role.createdTimestamp + 6 * 3600000);
                        createdtime = createdts.toLocaleString();
                        embed = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .addFields({
                            name: 'Role Information:',
                            value: "**`\u2022` Role Name**: <@&".concat(role.id, ">\n**`\u2022` User in Role**: **`").concat(role.members.size, "` Users**    \n**`\u2022` Displayed Seperately**: **`").concat(displayed, "`**  \n**`\u2022` Role Creation Date**: ").concat(createdtime, "  \n**`\u2022` Mentionable**: **`").concat(mentionable, "`**\n**`\u2022` Role Color**: **`").concat(role.hexColor, "`**")
                        });
                        return [4 /*yield*/, interaction.editReply({ embeds: [embed] })];
                    case 15:
                        _f.sent();
                        return [3 /*break*/, 41];
                    case 16:
                        if (!(interaction.options.getSubcommand() === 'role-perm')) return [3 /*break*/, 17];
                        role = interaction.options.getRole('target');
                        rolePermissions = role.permissions
                            .toArray()
                            .map(function (p) { return "`".concat(p, "`"); })
                            .join(', ');
                        embed = new EmbedBuilder()
                            .setTitle("Role Permissions")
                            .addFields({
                            name: '**`•`** Role Name',
                            value: "> <@&".concat(role.id, "> (").concat(role.id, ")"),
                            inline: true
                        }, {
                            name: '**`•`** Role Permissions',
                            value: "".concat(rolePermissions || 'None'),
                            inline: false
                        })
                            .setTimestamp()
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' });
                        interaction.editReply({ embeds: [embed], ephemeral: true });
                        return [3 /*break*/, 41];
                    case 17:
                        if (!(interaction.options.getSubcommand() === 'server')) return [3 /*break*/, 18];
                        guild = interaction.guild;
                        members = guild.members, channels_1 = guild.channels, emojis = guild.emojis, roles = guild.roles, stickers = guild.stickers;
                        sortedRoles = roles.cache
                            .map(function (role) { return role; })
                            .slice(1, roles.cache.size)
                            .sort(function (a, b) { return b.position - a.position; });
                        userRoles = sortedRoles.filter(function (role) { return !role.managed; });
                        managedRoles = sortedRoles.filter(function (role) { return role.managed; });
                        botCount = members.cache.filter(function (member) { return member.user.bot; }).size;
                        maxDisplayRoles = function (roles, maxFieldLength) {
                            if (maxFieldLength === void 0) { maxFieldLength = 1024; }
                            var totalLength = 0;
                            var result = [];
                            for (var _i = 0, roles_1 = roles; _i < roles_1.length; _i++) {
                                var role = roles_1[_i];
                                var roleString = "<@&".concat(role.id, ">");
                                if (roleString.length + totalLength > maxFieldLength)
                                    break;
                                totalLength += roleString.length + 1;
                                result.push(roleString);
                            }
                            return result.length;
                        };
                        splitPascal_1 = function (string, separator) {
                            return string.split(/(?=[A-Z])/).join(separator);
                        };
                        toPascalCase_1 = function (string, separator) {
                            if (separator === void 0) { separator = false; }
                            var pascal = string.charAt(0).toUpperCase() +
                                string
                                    .slice(1)
                                    .toLowerCase()
                                    .replace(/[^a-zA-Z0-9]+(.)/g, function (match, chr) { return chr.toUpperCase(); });
                            return separator ? splitPascal_1(pascal, separator) : pascal;
                        };
                        getChannelTypeSize = function (type) {
                            return channels_1.cache.filter(function (channel) { return type.includes(channel.type); }).size;
                        };
                        totalChannels = getChannelTypeSize([
                            ChannelType.GuildText,
                            ChannelType.GuildNews,
                            ChannelType.GuildVoice,
                            ChannelType.GuildStageVoice,
                            ChannelType.GuildForum,
                            ChannelType.GuildPublicThread,
                            ChannelType.GuildPrivateThread,
                            ChannelType.GuildNewsThread,
                            ChannelType.GuildCategory,
                        ]);
                        interaction.editReply({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor('#2F3136')
                                    .setTitle("".concat(guild.name, "'s Information"))
                                    .setThumbnail(guild.iconURL({ size: 1024 }))
                                    .setFooter({ text: '©2022 - 2023 | Reliable' })
                                    .setImage(guild.bannerURL({ size: 1024 }))
                                    .addFields({
                                    name: '**`🌐`** | General',
                                    value: [
                                        "**`\u2022`** **Created On** <t:".concat(parseInt(guild.createdTimestamp / 1000), ":R>"),
                                        "**`\u2022`** **Server ID** **`".concat(guild.id, "`**"),
                                        "**`\u2022`** **Owner** <@".concat(guild.ownerId, "> (**`").concat(guild.ownerId, "`**)"),
                                        "**`\u2022`** **Language** **`".concat(new Intl.DisplayNames(['en'], {
                                            type: 'language'
                                        }).of(guild.preferredLocale), "`**"),
                                        "**`\u2022`** **Vanity URL** ".concat(guild.vanityURLCode || '**`None`**'),
                                    ].join('\n')
                                }, {
                                    name: '**`📝`** | Description',
                                    value: "> ".concat(guild.description || '**`None`**')
                                }, {
                                    name: '<a:reliable_info:1030410449579147314> | Features',
                                    value: ((_e = (_d = guild.features) === null || _d === void 0 ? void 0 : _d.map(function (feature) {
                                        return "<:reliable_right:1042843202429919272> ".concat(toPascalCase_1(feature, ' '));
                                    })) === null || _e === void 0 ? void 0 : _e.join('\n')) || '**`None`**',
                                    inline: true
                                }, {
                                    name: '<:reliable_moderation:1030443113958875236> | Security',
                                    value: [
                                        "**`\uD83D\uDC40`** **Explicit Filter**  **`".concat(splitPascal_1(GuildExplicitContentFilter[guild.explicitContentFilter], ' '), "`**"),
                                        "**`\uD83D\uDD1E`** **NSFW Level** **`".concat(splitPascal_1(GuildNSFWLevel[guild.nsfwLevel], ' '), "`**"),
                                        "**`\uD83D\uDD12`** **Verification Level** **`".concat(splitPascal_1(GuildVerificationLevel[guild.verificationLevel], ' '), "`**"),
                                    ].join('\n'),
                                    inline: true
                                }, {
                                    name: "<a:reliable_members:1030037727485362197> | Users (**`".concat(guild.memberCount, "`**)"),
                                    value: [
                                        "**`\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67\u200D\uD83D\uDC66`** **Members** **`".concat(guild.memberCount - botCount, "`**"),
                                        "**`\uD83E\uDD16`** **Bots** **`".concat(botCount, "`**"),
                                    ].join('\n'),
                                    inline: true
                                }, {
                                    name: "<:reliable_earlysupporter:1030801808400056421> | Roles (**`".concat(maxDisplayRoles(userRoles), "` of `").concat(userRoles.length, "`**)"),
                                    value: "".concat(userRoles.slice(0, maxDisplayRoles(userRoles)).join(' ') ||
                                        '**`None`**')
                                }, {
                                    name: "**`\uD83D\uDC77\u200D\u2642\uFE0F`** | Managed Roles (**`".concat(maxDisplayRoles(managedRoles), "` of `").concat(managedRoles.length, "`**)"),
                                    value: "".concat(managedRoles
                                        .slice(0, maxDisplayRoles(managedRoles))
                                        .join(' ') || '**`None`**')
                                }, {
                                    name: "**`\uD83C\uDF43`** | Channels, Threads & Categories (**`".concat(totalChannels, "`**)"),
                                    value: [
                                        "**`\u2022`** **Text** **`".concat(getChannelTypeSize([
                                            ChannelType.GuildText,
                                            ChannelType.GuildForum,
                                            ChannelType.GuildNews,
                                        ]), "`**"),
                                        "**`\u2022`** **Voice** **`".concat(getChannelTypeSize([
                                            ChannelType.GuildVoice,
                                            ChannelType.GuildStageVoice,
                                        ]), "`**"),
                                        "**`\u2022`** **Threads** **`".concat(getChannelTypeSize([
                                            ChannelType.GuildPublicThread,
                                            ChannelType.GuildPrivateThread,
                                            ChannelType.GuildNewsThread,
                                        ]), "`**"),
                                        "**`\u2022`** **Categories** **`".concat(getChannelTypeSize([
                                            ChannelType.GuildCategory,
                                        ]), "`**"),
                                    ].join('\n'),
                                    inline: true
                                }, {
                                    name: "**`\uD83C\uDF42` | **Emojis & Stickers (**`".concat(emojis.cache.size + stickers.cache.size, "`**)"),
                                    value: [
                                        "**`\u2022`** **Animated** **`".concat(emojis.cache.filter(function (emoji) { return emoji.animated; }).size, "`**"),
                                        "**`\u2022`** **Static** **`".concat(emojis.cache.filter(function (emoji) { return !emoji.animated; }).size, "`**"),
                                        "**`\u2022`** **Stickers** **`".concat(stickers.cache.size, "`**"),
                                    ].join('\n'),
                                    inline: true
                                }, {
                                    name: '**`🍁` | ** Boosting',
                                    value: [
                                        "**`\u2022`** **Tier** **`".concat(guild.premiumTier || '**None**', "`**"),
                                        "**`\u2022`** **Boosts** **`".concat(guild.premiumSubscriptionCount || '**None**', "`**"),
                                        "**`\u2022`** **Boosters** **`".concat(guild.members.cache.filter(function (member) { return member.roles.premiumSubscriberRole; }).size || '**None**', "`**"),
                                        "**`\u2022`** **Total Boosters** **`".concat(guild.members.cache.filter(function (member) { return member.premiumSince; })
                                            .size, "`**"),
                                    ].join('\n'),
                                    inline: true
                                }, {
                                    name: '`🧧` | Banner',
                                    value: guild.bannerURL() ? '** **' : '**`None`**'
                                }),
                            ],
                            ephemeral: false
                        });
                        return [3 /*break*/, 41];
                    case 18:
                        if (!(interaction.options.getSubcommand() === 'user')) return [3 /*break*/, 23];
                        target = interaction.options.getMember('target') || interaction.member;
                        user = target.user, presence = target.presence, roles = target.roles;
                        formatter = new Intl.ListFormat('en-GB', {
                            style: 'narrow',
                            type: 'conjunction'
                        });
                        return [4 /*yield*/, user.fetch()];
                    case 19:
                        _f.sent();
                        statusType = {
                            idle: '1FJj7pX.png',
                            dnd: 'fbLqSYv.png',
                            online: 'JhW7v9d.png',
                            invisible: 'dibKqth.png'
                        };
                        activityType_1 = [
                            '🕹 Playing',
                            '🎙 Streaming',
                            '🎧 Listening to',
                            '📺 Watching',
                            '🤹🏻‍♀️ Custom',
                            '🏆 Competing in',
                        ];
                        clientType = [
                            { name: 'desktop', text: 'Computer', emoji: '💻' },
                            { name: 'mobile', text: 'Phone', emoji: '📱' },
                            { name: 'web', text: 'Website', emoji: '🔌' },
                            { name: 'offline', text: 'Offline', emoji: '💤' },
                        ];
                        flags_1 = {
                            BugHunterLevel1: '<:reliable_bughunter:1030800879680507954 [**`Bug Hunter Level 1`**]',
                            BugHunterLevel2: '<:reliable_bughunter2:1030800967207243836 [**`Bug Hunter Level 2`**]',
                            CertifiedModerator: '<:reliable_moderation:1030443113958875236> [**`Certified Moderator`**]',
                            HypeSquadOnlineHouse1: '<:reliable_hypersquadbravery:1030801385706500150> [**`HyperSquad Bravery`**]',
                            HypeSquadOnlineHouse2: '<:reliable_hypesquadbrilliance:1030800522787176448> [**`HyperSquad Brilliance`**]',
                            HypeSquadOnlineHouse3: '<:reliable_hypersquadbalance:1030801362126114910> [**`HyperSquad Balance`**]',
                            Hypesquad: '<:reliable_hypesquadbrilliance:1030800522787176448>  [**`HyperSquad Brilliance`**]',
                            Partner: '<:reliable_discordparthner:1030801628741247066> [**`Discord Parthner`**]',
                            PremiumEarlySupporter: '<:reliable_earlysupporter:1030801808400056421>  [**`Early Supporter`**]',
                            Staff: '<:reliable_DiscordStaff:1030802121945260042> [**`Discord Staff`**]',
                            VerifiedBot: '<:reliable_verifedbot:1030802332298006598> [**`Verified Bot`**]',
                            ActiveDeveloper: '<:reliable_activedeveloper:1040628618344288286> [**`Active Developer`**]',
                            VerifiedDeveloper: '<a:reliable_developer:1030802329139675156> [**`Verified Developer`**]',
                            NITRO: '<:reliable_nitro:1053162461529911396> [**`Nitro`**]',
                            BOOSTER_1: '<:reliable_boost1:1053162540965826592> [**`Booster Level 1`**]',
                            BOOSTER_2: '<:reliable_boost2:1053163733347745823> [**`Booster Level 2`**]',
                            BOOSTER_3: '<:reliable_boost3:1053163885907157074> [**`Booster Level 3`**]',
                            BOOSTER_4: '<:reliable_boost4:1053164843202515036> [**`Booster Level 4`**]',
                            BOOSTER_5: '<:reliable_boost5:1053163087865331744> [**`Booster Level 5`**]',
                            BOOSTER_6: '<:reliable_boost6:1053162620292694077> [**`Booster Level 6`**]',
                            BOOSTER_7: '<:reliable_boost7:1053162572527972462> [**`Booster Level 7`**]',
                            BOOSTER_8: '<:reliable_boost8:1053162854687182858> [**`Booster Level 8`**]',
                            BOOSTER_9: '<:reliable_boost9:1053162671056363531> [**`Booster Level 9`**]'
                        };
                        maxDisplayRoles = function (roles, maxFieldLength) {
                            if (maxFieldLength === void 0) { maxFieldLength = 1024; }
                            var totalLength = 0;
                            var result = [];
                            for (var _i = 0, roles_2 = roles; _i < roles_2.length; _i++) {
                                var role = roles_2[_i];
                                var roleString = "<@&".concat(role.id, ">");
                                if (roleString.length + totalLength > maxFieldLength)
                                    break;
                                totalLength += roleString.length + 1; // +1 as it's likely we want to display them with a space between each role, which counts towards the limit.
                                result.push(roleString);
                            }
                            return result.length;
                        };
                        return [4 /*yield*/, fetch("https://japi.rest/discord/v1/user/".concat(target.id))];
                    case 20:
                        response = _f.sent();
                        return [4 /*yield*/, response.json()];
                    case 21:
                        data = _f.sent();
                        sortedRoles = roles.cache
                            .map(function (role) { return role; })
                            .sort(function (a, b) { return b.position - a.position; })
                            .slice(0, roles.cache.size - 1);
                        clientStatus_1 = (presence === null || presence === void 0 ? void 0 : presence.clientStatus) instanceof Object
                            ? Object.keys(presence.clientStatus)
                            : 'offline';
                        userFlags = user.flags.toArray();
                        badges = data.data.public_flags_array
                            ? data.data.public_flags_array.map(function (flag) { return flags_1[flag]; }).join(' ')
                            : 'No Badges.';
                        badges2 = userFlags.length
                            ? formatter.format(userFlags.map(function (flag) { return "**".concat(flags_1[flag], "**"); }))
                            : '**`None`**';
                        deviceFilter = clientType.filter(function (device) {
                            return clientStatus_1.includes(device.name);
                        });
                        devices = !Array.isArray(deviceFilter)
                            ? new Array(deviceFilter)
                            : deviceFilter;
                        embed = new EmbedBuilder()
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' })
                            .setAuthor({
                            name: user.tag,
                            iconURL: "https://i.imgur.com/".concat(statusType[(presence === null || presence === void 0 ? void 0 : presence.status) || 'invisible'])
                        })
                            .setImage(user.bannerURL({ size: 1024 }))
                            .addFields({ name: '`🆔` | ID', value: "**`".concat(user.id, "`**") }, {
                            name: ' `⭐` | Activities',
                            value: (presence === null || presence === void 0 ? void 0 : presence.activities.map(function (activity) {
                                return "` ".concat(activityType_1[activity.type], " ").concat(activity.name, " ` ");
                            }).join('\n')) || '**`None`**'
                        }, {
                            name: ' `📆` | Account Created',
                            value: "<t:".concat(parseInt(user.createdTimestamp / 1000), ":R>"),
                            inline: true
                        }, {
                            name: '`🤝🏻` | Joined Server',
                            value: "<t:".concat(parseInt(target.joinedTimestamp / 1000), ":R>"),
                            inline: true
                        }, {
                            name: ' `🦸🏻‍♀️` | Nickname',
                            value: "**".concat(user.nickname || '**`None`**', "**"),
                            inline: true
                        }, {
                            name: "`\uD83C\uDF42` | Roles (".concat(maxDisplayRoles(sortedRoles), " of ").concat(sortedRoles.length, ")"),
                            value: "".concat(sortedRoles.slice(0, maxDisplayRoles(sortedRoles)).join(' ') ||
                                '**`None`**')
                        }, {
                            name: "`\uD83C\uDF8B` | Badges",
                            value: "".concat(badges, " ").concat(badges2)
                        }, {
                            name: "`\uD83C\uDF80` | Devices",
                            value: devices
                                .map(function (device) { return "**`".concat(device.emoji, " ").concat(device.text, "`**"); })
                                .join('\n'),
                            inline: true
                        }, {
                            name: ' `🖤` | Boosting Server',
                            value: "".concat(roles.premiumSubscriberRole
                                ? "**`Since`** <t:".concat(parseInt(target.premiumSinceTimestamp / 1000), ":R>")
                                : '**`No`**'),
                            inline: true
                        }, {
                            name: ' `🎏` | Banner',
                            value: user.bannerURL() ? '** **' : '**`None`**'
                        });
                        avatarbutton = new ButtonBuilder()
                            .setLabel("Avatar Link")
                            .setEmoji('<:reliable_earlysupporter:1030801808400056421>')
                            .setStyle(ButtonStyle.Link)
                            .setURL("".concat(user.avatarURL({ size: 1024, dynamic: true, format: 'png' }) ||
                            'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/75bff394-4f86-45a8-a923-e26223aa74cb/de901o7-d61b3bfb-f1b1-453b-8268-9200130bbc65.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzc1YmZmMzk0LTRmODYtNDVhOC1hOTIzLWUyNjIyM2FhNzRjYlwvZGU5MDFvNy1kNjFiM2JmYi1mMWIxLTQ1M2ItODI2OC05MjAwMTMwYmJjNjUucG5nIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.aEck9OnRf_XJzrEzZNvrGS2XpAlo2ixuxoAX5fgpNnw'));
                        return [4 /*yield*/, interaction.editReply({
                                embeds: [embed],
                                components: [new ActionRowBuilder().addComponents(avatarbutton)],
                                ephemeral: false
                            })];
                    case 22:
                        _f.sent();
                        return [3 /*break*/, 41];
                    case 23:
                        if (!(interaction.options.getSubcommand() === 'user-perm')) return [3 /*break*/, 24];
                        member = interaction.options.getMember('target') || interaction.member;
                        memberPermissions = member.permissions
                            .toArray()
                            .map(function (p) { return "`".concat(p, "`"); })
                            .join(', ');
                        embed = new EmbedBuilder()
                            .setTitle("User Permissions")
                            .addFields({
                            name: '**`•`** User Name',
                            value: "> <@".concat(member.id, "> (").concat(member.id, ")"),
                            inline: true
                        }, {
                            name: '**`•`** User Permissions',
                            value: "".concat(memberPermissions),
                            inline: false
                        })
                            .setTimestamp()
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' });
                        interaction.editReply({ embeds: [embed], ephemeral: true });
                        return [3 /*break*/, 41];
                    case 24:
                        if (!(interaction.options.getSubcommand() === 'space')) return [3 /*break*/, 25];
                        fetch('http://api.open-notify.org/iss-now.json')
                            .then(function (res) { return res.json(); })
                            .then(function (out) {
                            var iss_info = out;
                            var position = iss_info['iss_position'];
                            var latitude = position['latitude'];
                            var longitude = position['longitude'];
                            var Embed = new EmbedBuilder()
                                .setTitle('__Space Information__')
                                .setDescription("\n            Space refers to the vast and empty expanse beyond Earth's atmosphere, characterized by a near-vacuum environment. It encompasses celestial bodies, galaxies, and cosmic phenomena. Space exploration enables us to study the universe, its origins, and its mysteries, providing insights into our place in the cosmos.")
                                .setColor('#2F3136')
                                .addFields({
                                name: '__ISS Information__',
                                value: "**`\u00BB` Latitude**: `".concat(latitude, "`\n**`\u00BB` Longitude**: `").concat(longitude, "`"),
                                inline: true
                            })
                                .setFooter({ text: 'Reliable | Your trusted assistant' })
                                .setTimestamp();
                            interaction.editReply({ embeds: [Embed] });
                        });
                        return [3 /*break*/, 41];
                    case 25:
                        if (!(interaction.options.getSubcommand() === 'apod')) return [3 /*break*/, 26];
                        fetch('https://api.nasa.gov/planetary/apod?api_key=l2eGLkw7K710Z3JKP9abb0v0VGfRC03rJgo3frvo')
                            .then(function (res) { return res.json(); })
                            .then(function (json) {
                            var Embed = new EmbedBuilder()
                                .setTitle("".concat(json.title))
                                .setColor('#2F3136')
                                .setDescription(">>> **".concat(json.explanation, "**"))
                                .addFields({
                                name: '**`•`** Last Updated',
                                value: "> **`".concat(json.date, "`**"),
                                inline: true
                            }, {
                                name: '**`•`** Copyright',
                                value: "> **`".concat(json.copyright, "`**"),
                                inline: true
                            })
                                .setImage("".concat(json.hdurl))
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.editReply({ embeds: [Embed] });
                        });
                        return [3 /*break*/, 41];
                    case 26:
                        if (!(interaction.options.getSubcommand() === 'quotes')) return [3 /*break*/, 27];
                        fetch('https://api.popcat.xyz/quote')
                            .then(function (res) { return res.json(); })
                            .then(function (json) {
                            var Embed = new EmbedBuilder()
                                .setTitle("Quotes")
                                .setColor('#2F3136')
                                .setDescription(">>> **".concat(json.quote, "**"))
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.editReply({ embeds: [Embed] });
                        });
                        return [3 /*break*/, 41];
                    case 27:
                        if (!(interaction.options.getSubcommand() === 'translate')) return [3 /*break*/, 33];
                        query = interaction.options.getString('query');
                        raw = query;
                        from = interaction.options.getString('from');
                        to = interaction.options.getString('to');
                        _f.label = 28;
                    case 28:
                        _f.trys.push([28, 31, , 32]);
                        return [4 /*yield*/, translate(query, {
                                from: "".concat(from),
                                to: "".concat(to)
                            })];
                    case 29:
                        translated = _f.sent();
                        Embed_1 = new EmbedBuilder()
                            .setTitle('Translation')
                            .addFields({
                            name: '**`•` From**',
                            value: "> **`".concat(from, "`**"),
                            inline: true
                        }, {
                            name: '**`•` To**',
                            value: "> **`".concat(to, "`**"),
                            inline: true
                        }, { name: '**`•` Raw**', value: '```' + raw + '```' }, {
                            name: '**`•` Translated**',
                            value: '```' + translated.text + '```'
                        })
                            .setTimestamp()
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' });
                        return [4 /*yield*/, interaction.editReply({ embeds: [Embed_1] })];
                    case 30: return [2 /*return*/, _f.sent()];
                    case 31:
                        err_1 = _f.sent();
                        err_embed = new EmbedBuilder()
                            .setTitle('Error')
                            .setDescription('**<:reliable_wrong:1043155193077960764> | Please send a valid** [ISO 639-1](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes) **destination language code.**')
                            .setTimestamp()
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' });
                        interaction.editReply({ embeds: [err_embed], ephemeral: true });
                        return [3 /*break*/, 32];
                    case 32: return [3 /*break*/, 41];
                    case 33:
                        if (!(interaction.options.getSubcommand() === 'twitter')) return [3 /*break*/, 38];
                        user = interaction.options.getString('account');
                        _f.label = 34;
                    case 34:
                        _f.trys.push([34, 36, , 37]);
                        return [4 /*yield*/, twitter.users(user)];
                    case 35:
                        body = _f.sent();
                        verifiedtweet = 'No';
                        if (body.verified === true) {
                            verifiedtweet = 'Yes';
                        }
                        tweet = new EmbedBuilder()
                            .setTitle('Twitter Account')
                            .addFields({
                            name: 'Twitter Information Listed',
                            value: "**`\u2022` Account ID**: **`".concat(body.id, "`**\n**`\u2022` Followers**: **`").concat(body.followers_count.toLocaleString(), "`**\n**`\u2022` Tweets**: **`").concat(body.statuses_count.toLocaleString(), "`**\n**`\u2022` Following**: **`").concat(body.friends_count.toLocaleString(), "`**\n**`\u2022` Account Verified**: **<a:reliable_verified:1041749335735537704> `").concat(verifiedtweet || 'No', "`**\n**`\u2022` Account Creation Date**: **`").concat(moment
                                .utc(body.created_at)
                                .format('dddd, MMMM, Do YYYY'), "`**\n**`\u2022` Account Description**: ```").concat(body.description || 'None', "```")
                        })
                            .setThumbnail(body.profile_image_url_https.replace('_normal', ''))
                            .setImage(body.profile_banner_url)
                            .setTimestamp()
                            .setColor('#2F3136')
                            .setFooter({ text: '©2022 - 2023 | Reliable' });
                        interaction.editReply({ embeds: [tweet] });
                        return [3 /*break*/, 37];
                    case 36:
                        e_1 = _f.sent();
                        console.log(e_1);
                        if (e_1.status === 403) {
                            err_embed = new EmbedBuilder()
                                .setTitle("Error")
                                .setDescription('**<:reliable_wrong:1043155193077960764> | This user is in private mode, or deleted account!**')
                                .setTimestamp()
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.editReply({ embeds: [err_embed], ephemeral: true });
                        }
                        if (e_1.status === 404) {
                            err_embed2 = new EmbedBuilder()
                                .setTitle("Error")
                                .setDescription("**<:reliable_wrong:1043155193077960764> | Unknown error: `".concat(e_1.message, "`**"))
                                .setTimestamp()
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.editReply({ embeds: [err_embed2], ephemeral: true });
                        }
                        return [3 /*break*/, 37];
                    case 37: return [3 /*break*/, 41];
                    case 38:
                        if (!(interaction.options.getSubcommand() === 'movie')) return [3 /*break*/, 40];
                        imob = new imdb.Client({ apiKey: '5e36f0db' });
                        return [4 /*yield*/, imob.get({
                                name: interaction.options.getString('name')
                            })];
                    case 39:
                        movie = _f.sent();
                        try {
                            Embed_2 = new EmbedBuilder()
                                .setTitle("".concat(movie.title))
                                .setImage(movie.poster)
                                .setDescription("> **".concat(movie.plot, "**"))
                                .addFields({
                                name: 'Movie Info',
                                value: "**`\u2022` Country**: **`".concat(movie.country || 'N/A', "`**\n**`\u2022` Languages**: **`").concat(movie.languages || 'N/A', "`**\n**`\u2022` Type**: **`").concat(movie.type || 'N/A', "`**\n**`\u2022` Parental Rating**: **`").concat(movie.rated || 'N/A', "`**\n**`\u2022` Overall Rating**: **`").concat(movie.rating || 'N/A', "`**\n**`\u2022` Release Date**: **`").concat(movie.released || 'N/A', "`**\n**`\u2022` Runtime**: **`").concat(movie.runtime || 'N/A', "`**\n**`\u2022` Director**: **`").concat(movie.director || 'N/A', "`**\n**`\u2022` Writers**: **`").concat(movie.writers || 'N/A', "`**\n**`\u2022` Actors**: **`").concat(movie.actors || 'N/A', "`**\n**`\u2022` Year**: **`").concat(movie.year || 'N/A', "`**")
                            })
                                .setTimestamp()
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.editReply({ embeds: [Embed_2] });
                        }
                        catch (err) {
                            console.log(err);
                            err_embed = new EmbedBuilder()
                                .setTitle('Error')
                                .setDescription('**<:reliable_wrong:1043155193077960764> | Please send a valid movie name!**')
                                .setTimestamp()
                                .setColor('#2F3136')
                                .setFooter({ text: '©2022 - 2023 | Reliable' });
                            interaction.editReply({ embeds: [err_embed], ephemeral: true });
                        }
                        return [3 /*break*/, 41];
                    case 40:
                        if (interaction.options.getSubcommand() === 'season') {
                            country = interaction.options.getString('country');
                            try {
                                fetch("https://seasonapi.iamsohom829.repl.co/api/get-current-season/?api_key=da768dcebb706dd028da555a79308766ece0ef364641115ed6f1be9b96cf406c&country=".concat(country))
                                    .then(function (res) { return res.json(); })
                                    .then(function (json) {
                                    var Embed = new EmbedBuilder()
                                        .setTitle("Season")
                                        .setDescription("> **".concat(json.season, "**\n > **").concat(json.year, "**"))
                                        .setTimestamp()
                                        .setColor('#2F3136')
                                        .setFooter({ text: '©2022 - 2023 | Reliable' });
                                    interaction.editReply({ embeds: [Embed] });
                                });
                            }
                            catch (err) {
                                console.log(err);
                                err_embed = new EmbedBuilder()
                                    .setTitle('Error')
                                    .setDescription('**<:reliable_wrong:1043155193077960764> | Please send a valid movie name!**')
                                    .setTimestamp()
                                    .setColor('#2F3136')
                                    .setFooter({ text: '©2022 - 2023 | Reliable' });
                                interaction.editReply({ embeds: [err_embed], ephemeral: true });
                            }
                        }
                        else if (interaction.options.getSubcommand() === 'weather') {
                            try {
                                place = interaction.options.getString('place');
                                axios
                                    .get("https://luminabot.xyz/api/json/weather?location=".concat(place, "&degreetype=C"))
                                    .then(function (res) { return res.data; })
                                    .then(function (json) {
                                    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2;
                                    var Embed = new EmbedBuilder()
                                        .setTitle("Weather Information")
                                        .setThumbnail("https:".concat((_a = json.current.condition) === null || _a === void 0 ? void 0 : _a.icon))
                                        .addFields({
                                        name: '`🏞️` | Location Info',
                                        value: "**`\u2022` Location Name**: **`".concat(((_b = json.location) === null || _b === void 0 ? void 0 : _b.name) || 'N/A', "`**\n**`\u2022` Region**: **`").concat(((_c = json.location) === null || _c === void 0 ? void 0 : _c.region) || 'N/A', "`**\n**`\u2022` Country**: **`").concat(((_d = json.location) === null || _d === void 0 ? void 0 : _d.country) || 'N/A', "`**\n**`\u2022` Lat & Lon**: **`").concat(((_e = json.location) === null || _e === void 0 ? void 0 : _e.lat) || 'N/A', " & ").concat(((_f = json.location) === null || _f === void 0 ? void 0 : _f.lon) || 'N/A', "`**\n**`\u2022` Time Zone Identifier**: **`").concat(((_g = json.location) === null || _g === void 0 ? void 0 : _g.tz_id) || 'N/A', "`**\n**`\u2022` Local Time**: **`").concat(((_h = json.location) === null || _h === void 0 ? void 0 : _h.localtime) || 'N/A', "`**")
                                    }, {
                                        name: '`🌥️` | Weather Condition Info',
                                        value: "**`\u2022` Condition**: **`".concat(((_j = json.current.condition) === null || _j === void 0 ? void 0 : _j.text) || 'N/A', "`**\n**`\u2022` Feels Like**: **`").concat(json.current.feelslike_c || 'N/A', "\u00B0C & ").concat(json.current.feelslike_f || 'N/A', "\u00B0F`**\n**`\u2022` Humidity**: **`").concat(json.current.humidity || 'N/A', "%`**\n**`\u2022` Last Updated**: **<t:").concat(((_k = json.current) === null || _k === void 0 ? void 0 : _k.last_updated_epoch) || 'N/A', ":F>**")
                                    }, {
                                        name: '`☁️` | Wind Info',
                                        value: "**`\u2022` Wind Speed**: **`".concat(((_l = json.current) === null || _l === void 0 ? void 0 : _l.wind_mph) || 'N/A', "mi/h & ").concat(((_m = json.current) === null || _m === void 0 ? void 0 : _m.wind_kph) || 'N/A', "km/h`**\n**`\u2022` Wind Direction**: **`").concat(json.current.wind_dir || 'N/A', "`**\n**`\u2022` Wind Degree**: **`").concat(json.current.wind_degree || 'N/A', "`**\n**`\u2022` Pressure**: **`").concat(((_o = json.current) === null || _o === void 0 ? void 0 : _o.pressure_mb) || 'N/A', "MB & ").concat(((_p = json.current) === null || _p === void 0 ? void 0 : _p.pressure_in) || 'N/A', "IN`**\n**`\u2022` Precip**: **`").concat(((_q = json.current) === null || _q === void 0 ? void 0 : _q.precip_mm) || 'N/A', "MM & ").concat(((_r = json.current) === null || _r === void 0 ? void 0 : _r.precip_in) || 'N/A', "IN`**\n**`\u2022` Visibility**: **`").concat(((_s = json.current) === null || _s === void 0 ? void 0 : _s.vis_miles) || 'N/A', "mi & ").concat(((_t = json.current) === null || _t === void 0 ? void 0 : _t.vis_km) || 'N/A', "km`**\n**`\u2022` Gust**: **`").concat(((_u = json.current) === null || _u === void 0 ? void 0 : _u.gust_mph) || 'N/A', "mi/h & ").concat(((_v = json.current) === null || _v === void 0 ? void 0 : _v.gust_kph) || 'N/A', "km/h`**\n**`\u2022` UV**: **`").concat(((_w = json.current) === null || _w === void 0 ? void 0 : _w.uv) || 'N/A', "`**")
                                    }, {
                                        name: '`💨` | Air Quality',
                                        value: "**`\u2022` Co**: **`".concat(((_x = json.current.air_quality) === null || _x === void 0 ? void 0 : _x.co) || 'N/A', "`**\n**`\u2022` O3**: **`").concat(((_y = json.current.air_quality) === null || _y === void 0 ? void 0 : _y.o3) || 'N/A', "`**\n**`\u2022` No2**: **`").concat(((_z = json.current.air_quality) === null || _z === void 0 ? void 0 : _z.no2) || 'N/A', "`**\n**`\u2022` So2**: **`").concat(((_0 = json.current.air_quality) === null || _0 === void 0 ? void 0 : _0.so2) || 'N/A', "`**\n**`\u2022` PM2.5**: **`").concat(((_1 = json.current.air_quality) === null || _1 === void 0 ? void 0 : _1.pm2_5) || 'N/A', "`**\n**`\u2022` PM10**: **`").concat(((_2 = json.current.air_quality) === null || _2 === void 0 ? void 0 : _2.pm10) || 'N/A', "`**")
                                    })
                                        .setTimestamp()
                                        .setColor('#2F3136')
                                        .setFooter({ text: '©2022 - 2023 | Reliable' });
                                    interaction.editReply({ embeds: [Embed] });
                                });
                            }
                            catch (err) {
                                console.log(err);
                                err_embed = new EmbedBuilder()
                                    .setTitle('Error')
                                    .setDescription('**<:reliable_wrong:1043155193077960764> | Something went wrong**')
                                    .setTimestamp()
                                    .setColor('#2F3136')
                                    .setFooter({ text: '©2022 - 2023 | Reliable' });
                                interaction.editReply({ embeds: [err_embed], ephemeral: true });
                            }
                        }
                        else if (interaction.options.getSubcommand() === 'country') {
                            try {
                                country = interaction.options.getString('name');
                                fetch("https://restcountries.com/v3.1/name/".concat(country))
                                    .then(function (res) { return res.json(); })
                                    .then(function (json) {
                                    var _a, _b, _c;
                                    var data = json[0];
                                    var independent = 'No';
                                    if (data.independent === true) {
                                        independent = 'Yes';
                                    }
                                    var unMember = 'No';
                                    if (data.unMember === true) {
                                        unMember = 'Yes';
                                    }
                                    var Embed = new EmbedBuilder()
                                        .setTitle("Country Information")
                                        .setImage(data.flags.png)
                                        .addFields({
                                        name: '`🏞️` | General Info',
                                        value: "**`\u2022` Common Name**: **`".concat(((_a = data.name) === null || _a === void 0 ? void 0 : _a.common) || 'N/A', "`**\n**`\u2022` Official Name**: **`").concat(((_b = data.name) === null || _b === void 0 ? void 0 : _b.official) || 'N/A', "`**\n**`\u2022` Independent**: **`").concat(independent || 'N/A', "`**\n**`\u2022` Status**: **`").concat(data.status || 'N/A', "`**\n**`\u2022` United Nations Member**: **`").concat(unMember || 'N/A', "`**\n**`\u2022` Top-level domain**: **`").concat(data.tld[0] || 'N/A', "`**\n**`\u2022` Population**: **`").concat(data.population || 'N/A', "`**\n**`\u2022` Capital City**: **`").concat(data.capital[0] || 'N/A', "`**\n**`\u2022` Capital Lat & Lon**: **`").concat(((_c = data.capitalInfo) === null || _c === void 0 ? void 0 : _c.latlng) || 'N/A', "`**")
                                    }, {
                                        name: '`🌐` | External Info',
                                        value: "**`\u2022` FIFA**: **`".concat(data.fifa || 'N/A', "`**\n**`\u2022` Borders**: **`").concat(data.borders || 'N/A', "`**\n**`\u2022` TimeZones**: **`").concat(data.timezones[0] || 'N/A', "`**\n**`\u2022` Continents**: **`").concat(data.continents[0] || 'N/A', "`**\n**`\u2022` Start of Week**: **`").concat(data.startOfWeek || 'N/A', "`**")
                                    })
                                        .setTimestamp()
                                        .setColor('#2F3136')
                                        .setFooter({ text: '©2022 - 2023 | Reliable' });
                                    var googlemap = new ActionRowBuilder().addComponents(new ButtonBuilder()
                                        .setLabel("Map Link")
                                        .setEmoji('<:reliable_googlemaps:1046358219691405353>')
                                        .setStyle(ButtonStyle.Link)
                                        .setURL("".concat(data.maps.googleMaps)));
                                    interaction.editReply({ embeds: [Embed], components: [googlemap] });
                                });
                            }
                            catch (err) {
                                console.log(err);
                                err_embed = new EmbedBuilder()
                                    .setTitle('Error')
                                    .setDescription('**<:reliable_wrong:1043155193077960764> | Something went wrong**')
                                    .setTimestamp()
                                    .setColor('#2F3136')
                                    .setFooter({ text: '©2022 - 2023 | Reliable' });
                                interaction.editReply({ embeds: [err_embed], ephemeral: true });
                            }
                        }
                        else {
                            interaction.editReply({ content: "No sub command choosed" });
                        }
                        _f.label = 41;
                    case 41: return [2 /*return*/];
                }
            });
        });
    }
};
/**
 * @Author Reliable Inc.
 * @Copyright ©2022 - 2023 | Reliable Inc, All rights reserved.
 * @CodedBy Mohtasim Alam Sohom, Sajidur Rahman Tahsin
 */
//# sourceMappingURL=info.js.map