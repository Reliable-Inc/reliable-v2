import { ChatInputCommandInteraction } from "discord.js";
export let beta: boolean;
export let data: import("@discordjs/builders").SlashCommandSubcommandsOnlyBuilder;
/**
 *
 * @param {ChatInputCommandInteraction} interaction
 * @param {Client} client
 * @returns
 */
export function execute(interaction: ChatInputCommandInteraction<import("discord.js").CacheType>, client: Client): Promise<import("discord.js").Message<boolean> | undefined>;
//# sourceMappingURL=info.d.ts.map