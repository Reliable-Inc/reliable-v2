"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
var discordjs_colors_bundle_1 = require("discordjs-colors-bundle");
var node_musixmatch_api_1 = require("node-musixmatch-api");
var albumTrackAutoComplete_1 = require("./albumTrackAutoComplete");
var _a = require('discord.js'), SlashCommandBuilder = _a.SlashCommandBuilder, ButtonBuilder = _a.ButtonBuilder, ButtonStyle = _a.ButtonStyle, EmbedBuilder = _a.EmbedBuilder, ActionRowBuilder = _a.ActionRowBuilder, ChatInputCommandInteraction = _a.ChatInputCommandInteraction, Client = _a.Client;
var mxm = new node_musixmatch_api_1.Musixmatch();
mxm.setApiKey("".concat(process === null || process === void 0 ? void 0 : process.env['Musixmatch'].toString()));
var fs = require('fs');
var fetch = require('node-fetch');
var clientId = process.env['Spotify_Client_Id'];
var clientSecret = process.env['Spotify_Client_Secret'];
function getAccessToken() {
    return __awaiter(this, void 0, void 0, function () {
        var response, data;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, fetch('https://accounts.spotify.com/api/token', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                            Authorization: "Basic ".concat(Buffer.from("".concat(clientId, ":").concat(clientSecret)).toString('base64'))
                        },
                        body: 'grant_type=client_credentials'
                    })];
                case 1:
                    response = _a.sent();
                    return [4 /*yield*/, response.json()];
                case 2:
                    data = _a.sent();
                    return [2 /*return*/, data.access_token];
            }
        });
    });
}
function writeAccessTokenToFile(accessToken) {
    fs.writeFile('tokens.txt', accessToken, function (err) {
        if (err)
            throw err;
    });
}
getAccessToken()
    .then(function (accessToken) { return writeAccessTokenToFile(accessToken); })["catch"](function (err) { return console.error('Error retrieving access token:', err); });
setInterval(function () {
    getAccessToken()
        .then(function (accessToken) { return writeAccessTokenToFile(accessToken); })["catch"](function (err) { return console.error('Error retrieving access token:', err); });
}, 3600000);
function getTrackInfo(artistName, trackName) {
    return __awaiter(this, void 0, void 0, function () {
        var accessToken, searchParams, response, data, track, trackInfo;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getAccessToken()];
                case 1:
                    accessToken = _a.sent();
                    searchParams = new URLSearchParams();
                    searchParams.append('q', "artist:".concat(artistName, " track:").concat(trackName));
                    searchParams.append('type', 'track');
                    searchParams.append('limit', '1');
                    return [4 /*yield*/, fetch("https://api.spotify.com/v1/search?".concat(searchParams.toString()), {
                            headers: {
                                Authorization: "Bearer ".concat(accessToken)
                            }
                        })];
                case 2:
                    response = _a.sent();
                    return [4 /*yield*/, response.json()];
                case 3:
                    data = _a.sent();
                    if (data.tracks.items.length > 0) {
                        track = data.tracks.items[0];
                        trackInfo = {
                            name: track.name,
                            artists: track.artists.map(function (artist) { return artist.name; }),
                            album: track.album.name,
                            previewUrl: track.preview_url,
                            externalUrl: track.external_urls.spotify,
                            albumIcon: track.album.images[0].url,
                            durationMs: track.duration_ms,
                            trackId: track.id,
                            isrc: track.external_ids.isrc
                        };
                        return [2 /*return*/, trackInfo];
                    }
                    else {
                        throw new Error('Track not found');
                    }
                    return [2 /*return*/];
            }
        });
    });
}
module.exports = {
    beta: false,
    data: new SlashCommandBuilder()
        .setName('spotify')
        .setDescription('Initiate the 🎵 Spotify information command to access comprehensive details.')
        .addSubcommand(function (sub) {
        return sub.setName('current').setDescription('Get your current playing status.');
    })
        .addSubcommand(function (sub) {
        return sub
            .setName('info')
            .setDescription('Get your current playing information.');
    }),
    /**
     *
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     * @returns
     */
    execute: function (interaction, client) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function () {
            var member, activity, trackName, artistName, semicolonCount, aName, options, info, albumIcon, durationMs, minutes, seconds, formattedDuration, SpotifyId, deepSearch, albumId, id, albumName, hasLyrics, isInstrumental, isExplicit, trackRating, lyricsRes, lyrics, albumSearch, albumTracks, Embed, MXMLink, bcomponents;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0: return [4 /*yield*/, interaction.deferReply({ fetchReply: true, ephemeral: true })];
                    case 1:
                        _d.sent();
                        if (!(interaction.options.getSubcommand() == 'info')) return [3 /*break*/, 6];
                        member = interaction.member;
                        activity = member.presence.activities.find(function (activity) { return activity.type === 2 && activity.name === 'Spotify'; });
                        if (!activity) return [3 /*break*/, 6];
                        trackName = activity.details || 'Unknown';
                        artistName = activity.state.toString() || 'Unknown';
                        if (artistName.includes(';')) {
                            artistName = artistName.replace(/;/g, '');
                        }
                        semicolonCount = (activity.state.toString().match(/;/g) || [])
                            .length;
                        aName = 'Unknown';
                        if (semicolonCount === 1) {
                            aName = activity.state.toString().replace(';', ' feat.');
                        }
                        else if (semicolonCount === 2) {
                            aName = activity.state
                                .toString()
                                .replace(';', ' feat.')
                                .replace(';', ' &');
                        }
                        else if (semicolonCount >= 3) {
                            aName = activity.state
                                .toString()
                                .replace(';', ' feat.')
                                .replace(';', ',')
                                .replace(/;/g, ' &');
                        }
                        else {
                            aName = activity.state.toString().replace(/;/g, ',');
                        }
                        options = {
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                                'x-mxm-signature': 'v0pwaG293G5sXkpYHJ8fmPbpckw',
                                'x-mxm-signature-protocol': 'sha1'
                            },
                            AWSELB: '55578B011601B1EF8BC274C33F9043CA947F99DCFF6AB1B746DBF1E96A6F2B997493EE03F2045E23060D22ED54D7B8D422981DE4D537EFD5DCF9DA7B0658AA87EB7AE701D7',
                            AWSELBCORS: '55578B011601B1EF8BC274C33F9043CA947F99DCFF6AB1B746DBF1E96A6F2B997493EE03F2045E23060D22ED54D7B8D422981DE4D537EFD5DCF9DA7B0658AA87EB7AE701D7'
                        };
                        return [4 /*yield*/, getTrackInfo(artistName, trackName)];
                    case 2:
                        info = _d.sent();
                        albumIcon = info === null || info === void 0 ? void 0 : info.albumIcon;
                        durationMs = info === null || info === void 0 ? void 0 : info.durationMs;
                        minutes = Math.floor(durationMs / 60000);
                        seconds = Math.floor((durationMs % 60000) / 1000);
                        formattedDuration = "".concat(minutes, ":").concat(seconds
                            .toString()
                            .padStart(2, '0'));
                        SpotifyId = info === null || info === void 0 ? void 0 : info.trackId;
                        return [4 /*yield*/, mxm.trackGet("track_isrc=".concat(info === null || info === void 0 ? void 0 : info.isrc))];
                    case 3:
                        deepSearch = _d.sent();
                        albumId = deepSearch === null || deepSearch === void 0 ? void 0 : deepSearch.message.body.track.album_id;
                        id = deepSearch === null || deepSearch === void 0 ? void 0 : deepSearch.message.body.track.track_id;
                        albumName = info === null || info === void 0 ? void 0 : info.album;
                        hasLyrics = (deepSearch === null || deepSearch === void 0 ? void 0 : deepSearch.message.body.track.has_lyrics)
                            ? 'Yes'
                            : 'No';
                        isInstrumental = (deepSearch === null || deepSearch === void 0 ? void 0 : deepSearch.message.body.track.instrumental)
                            ? 'Yes'
                            : 'No';
                        isExplicit = (deepSearch === null || deepSearch === void 0 ? void 0 : deepSearch.message.body.track.explicit)
                            ? 'Yes'
                            : 'No';
                        trackRating = deepSearch === null || deepSearch === void 0 ? void 0 : deepSearch.message.body.track.track_rating;
                        return [4 /*yield*/, mxm.matcherLyricsGet("track_isrc=".concat(info === null || info === void 0 ? void 0 : info.isrc))];
                    case 4:
                        lyricsRes = _d.sent();
                        lyrics = (_a = lyricsRes.message.body.lyrics.lyrics_body.replace(/\*\* This Lyrics is NOT for Commercial use \*\*/g, '30% Lyrics By Musixmatch')) !== null && _a !== void 0 ? _a : 'Lyrics is unavailable.';
                        return [4 /*yield*/, (0, albumTrackAutoComplete_1.albumInfoGet)(albumId)];
                    case 5:
                        albumSearch = _d.sent();
                        albumTracks = albumSearch.message.body.track_list
                            .map(function (track, index) { return "".concat(index + 1, ". ").concat(track.track.track_name); })
                            .join('\n');
                        Embed = new EmbedBuilder()
                            .setTitle("__Your spotify status__")
                            .setDescription("Presenting an extensive and thorough overview of the complete information pertaining to your current Spotify listening session, including track name, artist name, album details, availability of lyrics, instrumental status, and explicit content classification. Please find the comprehensive report below, offering detailed insights into your present Spotify experience.")
                            .setColor(0x2f3136)
                            .setFooter({ text: 'Reliable | Your trusted assistant' })
                            .setDescription("## Lyrics:\n".concat(lyrics))
                            .addFields({
                            name: '__Track Information__',
                            value: "**`\u2023` Artist Name**: `".concat(aName !== null && aName !== void 0 ? aName : 'N/A', "`\n**`\u2023` Album Name**: `").concat(albumName !== null && albumName !== void 0 ? albumName : 'N/A', "`\n**`\u2023` Explicit**: `").concat(isExplicit !== null && isExplicit !== void 0 ? isExplicit : 'Yes', "`\n**`\u2023` Duration**: `").concat(formattedDuration !== null && formattedDuration !== void 0 ? formattedDuration : '0:00', "`\n**`\u2023` ISRC**: `").concat((_b = info === null || info === void 0 ? void 0 : info.isrc) !== null && _b !== void 0 ? _b : 'ABCDEFGH123', "`\n**`\u2023` ID**: `").concat(id !== null && id !== void 0 ? id : '12345678', "`\n**`\u2023` Album Id**: `").concat(albumId !== null && albumId !== void 0 ? albumId : '12345678', "`\n**`\u2023` Spotify Id**: `").concat(SpotifyId !== null && SpotifyId !== void 0 ? SpotifyId : '12345678', "`"),
                            inline: true
                        }, {
                            name: '**__More tracks on this album__**',
                            value: "".concat(albumTracks),
                            inline: true
                        })
                            .setThumbnail(albumIcon);
                        MXMLink = (_c = deepSearch === null || deepSearch === void 0 ? void 0 : deepSearch.message.body.track.track_share_url.split('?utm_source')[0]) !== null && _c !== void 0 ? _c : 'https://www.musixmatch.com';
                        bcomponents = new ActionRowBuilder().addComponents(new ButtonBuilder()
                            .setCustomId('torbap1')
                            .setLabel("Track Name: ".concat(trackName !== null && trackName !== void 0 ? trackName : 'N/A'))
                            .setStyle('Secondary')
                            .setDisabled(true), new ButtonBuilder()
                            .setCustomId('chudi1')
                            .setLabel("Has Lyrics?: ".concat(hasLyrics !== null && hasLyrics !== void 0 ? hasLyrics : 'No'))
                            .setStyle('Secondary')
                            .setDisabled(true), new ButtonBuilder()
                            .setCustomId('kutta1')
                            .setLabel("Instrumental: ".concat(isInstrumental !== null && isInstrumental !== void 0 ? isInstrumental : 'Yes'))
                            .setStyle('Secondary')
                            .setDisabled(true), new ButtonBuilder()
                            .setCustomId('kuttachuda1')
                            .setLabel("Track Rating Musixmatch: ".concat(trackRating !== null && trackRating !== void 0 ? trackRating : '0'))
                            .setStyle('Secondary')
                            .setDisabled(true), new ButtonBuilder()
                            .setLabel("Full Lyrics")
                            .setStyle('Link')
                            .setURL(MXMLink !== null && MXMLink !== void 0 ? MXMLink : 'https://www.musixmatch.com'));
                        return [2 /*return*/, interaction.editReply({
                                embeds: [Embed],
                                components: [bcomponents]
                            })];
                    case 6: return [2 /*return*/];
                }
            });
        });
    }
};
//# sourceMappingURL=spotify.js.map