declare function sleep(ms: number): Promise<unknown>;
/**
 *
 * @param inputText - The input text
 * @returns - The cleaned text
 */
declare function cleanText(inputText: string): string;
export { sleep, cleanText };
//# sourceMappingURL=globalFunc.d.ts.map