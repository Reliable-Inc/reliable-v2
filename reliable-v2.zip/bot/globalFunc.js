"use strict";
exports.__esModule = true;
exports.cleanText = exports.sleep = void 0;
function sleep(ms) {
    return new Promise(function (resolve) { return setTimeout(resolve, ms); });
}
exports.sleep = sleep;
/**
 *
 * @param inputText - The input text
 * @returns - The cleaned text
 */
function cleanText(inputText) {
    var cleanedText = inputText.replace(/[^a-zA-Z0-9\s]/g, '');
    var lowercaseText = cleanedText.toLowerCase();
    return lowercaseText;
}
exports.cleanText = cleanText;
//# sourceMappingURL=globalFunc.js.map