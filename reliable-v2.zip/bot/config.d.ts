export default Configuration;
declare namespace Configuration {
    let developerIds: string[];
    namespace botPresence {
        let status: PresenceUpdateStatus;
        let activity: string;
        let activityType: ActivityType;
    }
    let guildId: string;
    let redirectUri: string;
}
import { PresenceUpdateStatus } from 'discord.js';
import { ActivityType } from 'discord.js';
//# sourceMappingURL=config.d.ts.map