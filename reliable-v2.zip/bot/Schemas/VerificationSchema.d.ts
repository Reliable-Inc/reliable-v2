declare const VerificationRole: any;
export default VerificationRole;
//# sourceMappingURL=VerificationSchema.d.ts.map