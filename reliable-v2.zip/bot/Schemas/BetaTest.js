"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var mongoose_1 = __importDefault(require("mongoose"));
var Schema = mongoose_1["default"].Schema, model = mongoose_1["default"].model;
var BetaTestSchema = new Schema({
    userID: {
        type: Number,
        required: true
    },
    username: {
        type: String,
        required: true
    },
    addedBy: {
        type: String,
        required: true
    }
});
var BetaTestUsers = model('BetaTestUsers', BetaTestSchema);
exports["default"] = BetaTestUsers;
//# sourceMappingURL=BetaTest.js.map