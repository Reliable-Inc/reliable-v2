import mongoose from 'mongoose';
declare const GuildIDs: mongoose.Model<{
    guildId: number;
}, {}, {}, {}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    guildId: number;
}>>;
export default GuildIDs;
//# sourceMappingURL=AntiToxic.d.ts.map