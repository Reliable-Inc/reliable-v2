import mongoose from 'mongoose';
declare const BetaTestUsers: mongoose.Model<{
    userID: number;
    username: string;
    addedBy: string;
}, {}, {}, {}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    userID: number;
    username: string;
    addedBy: string;
}>>;
export default BetaTestUsers;
//# sourceMappingURL=BetaTest.d.ts.map