import mongoose from 'mongoose';
declare const AntiObsceneGuildIDs: mongoose.Model<{
    guildId: number;
}, {}, {}, {}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    guildId: number;
}>>;
export default AntiObsceneGuildIDs;
//# sourceMappingURL=AntiObscene.d.ts.map