import mongoose from 'mongoose';
declare const antiProfanity: mongoose.Model<{
    guildId: number;
}, {}, {}, {}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    guildId: number;
}>>;
export default antiProfanity;
//# sourceMappingURL=AntiProfanity.d.ts.map