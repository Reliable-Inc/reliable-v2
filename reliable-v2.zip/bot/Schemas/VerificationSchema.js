"use strict";
exports.__esModule = true;
var mongoose = require('mongoose');
var verificationRoleSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    roleId: { type: String, required: true }
});
var VerificationRole = mongoose.model('verificationRole', verificationRoleSchema);
exports["default"] = VerificationRole;
//# sourceMappingURL=VerificationSchema.js.map