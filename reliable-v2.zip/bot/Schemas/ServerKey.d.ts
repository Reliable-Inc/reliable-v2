import mongoose from 'mongoose';
declare const ServerKey: mongoose.Model<{
    key: string;
}, {}, {}, {}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    key: string;
}>>;
export default ServerKey;
//# sourceMappingURL=ServerKey.d.ts.map