import mongoose from 'mongoose';
declare const AntiThreatGuildIDs: mongoose.Model<{
    guildId: number;
}, {}, {}, {}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    guildId: number;
}>>;
export default AntiThreatGuildIDs;
//# sourceMappingURL=AntiThreat.d.ts.map