import mongoose from 'mongoose';
declare const Report: mongoose.Model<{
    BugTitle: string;
    BugDescription: string;
    BugExpectation: string;
    ReportedBy: string;
    ReportedPfp: string;
    ReportedDate: string;
}, {}, {}, {}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    BugTitle: string;
    BugDescription: string;
    BugExpectation: string;
    ReportedBy: string;
    ReportedPfp: string;
    ReportedDate: string;
}>>;
export default Report;
//# sourceMappingURL=Reports.d.ts.map