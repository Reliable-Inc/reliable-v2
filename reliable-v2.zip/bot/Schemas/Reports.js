"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var mongoose_1 = __importDefault(require("mongoose"));
var Schema = mongoose_1["default"].Schema, model = mongoose_1["default"].model;
var ReportsSchema = new Schema({
    BugTitle: {
        type: String,
        required: true
    },
    BugDescription: {
        type: String,
        required: true
    },
    BugExpectation: {
        type: String,
        required: true
    },
    ReportedBy: {
        type: String,
        required: true
    },
    ReportedPfp: {
        type: String,
        required: true
    },
    ReportedDate: {
        type: String,
        required: false,
        "default": formatDate
    }
});
function formatDate() {
    var date = new Date();
    var day = String(date.getDate()).padStart(2, '0');
    var month = new Intl.DateTimeFormat('en', { month: 'long' }).format(date);
    var year = date.getFullYear();
    return "".concat(day, " ").concat(month, " ").concat(year);
}
var Report = model('Report', ReportsSchema);
exports["default"] = Report;
//# sourceMappingURL=Reports.js.map