export {};
//# sourceMappingURL=verification.d.ts.map