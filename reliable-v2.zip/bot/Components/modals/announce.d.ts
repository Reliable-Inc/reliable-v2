export namespace data {
    let name: string;
}
export function execute(interaction: any, client: any): Promise<any>;
//# sourceMappingURL=announce.d.ts.map