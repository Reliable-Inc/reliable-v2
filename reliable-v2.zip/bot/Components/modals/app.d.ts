import { ModalSubmitInteraction } from "discord.js";
import { Client } from "discord.js";
export namespace data {
    let name: string;
}
/**
 * @param {ModalSubmitInteraction} interaction
 * @param {Client} client
 */
export function execute(interaction: ModalSubmitInteraction<import("discord.js").CacheType>, client: Client<boolean>): Promise<void>;
//# sourceMappingURL=app.d.ts.map