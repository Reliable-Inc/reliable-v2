export namespace data {
    let name: string;
}
export function execute(interaction: any, client: any): Promise<void>;
//# sourceMappingURL=test.d.ts.map