type ErrorType = 'Error' | 'TypeError' | 'SyntaxError' | 'ReferenceError' | 'RangeError' | 'Custom';
type ErrorName = string;
type ErrorMessage = string;
export declare function throwError(errorType: ErrorType, errorName: ErrorName, ...message: ErrorMessage[]): void;
export {};
/**
 * @INFO
 * Bot Coded by Sohom829#8350 & Alpha•#7395
 * You can't use this codes without permissions!
 * Powered By Reliable Inc.
 */
//# sourceMappingURL=checker.d.ts.map