"use strict";
exports.__esModule = true;
var discord_js_1 = require("discord.js");
var Configuration = {
    developerIds: [
        '1043709478031343647',
        '783661052738011176',
        '967657941937291265',
    ],
    botPresence: {
        status: discord_js_1.PresenceUpdateStatus.DoNotDisturb,
        activity: '/help',
        activityType: discord_js_1.ActivityType.Watching
    },
    guildId: '1029777893112418314',
    redirectUri: 'https://reliable-v2.mohtasimalamsoh.repl.co/callback'
};
exports["default"] = Configuration;
//# sourceMappingURL=config.js.map