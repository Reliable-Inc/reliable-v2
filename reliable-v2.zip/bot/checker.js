'use strict';
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var _a, _b, _c, _d, _e, _f, _g;
exports.__esModule = true;
exports.throwError = void 0;
var chalk_1 = __importDefault(require("chalk"));
var fs = __importStar(require("fs"));
var config_1 = __importDefault(require("./config"));
var dotenv_1 = __importDefault(require("dotenv"));
dotenv_1["default"].config();
var cyan = chalk_1["default"].cyan, blue = chalk_1["default"].blue, greenBright = chalk_1["default"].greenBright, red = chalk_1["default"].red, white = chalk_1["default"].white, yellow = chalk_1["default"].yellow, bold = chalk_1["default"].bold, whiteBright = chalk_1["default"].whiteBright, gray = chalk_1["default"].gray;
var ConfigurationError = /** @class */ (function (_super) {
    __extends(ConfigurationError, _super);
    /**
     * A Custom Error.
     * @param {Message[]} message - The error message
     */
    function ConfigurationError() {
        var message = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            message[_i] = arguments[_i];
        }
        var _this = _super.call(this, message.join(' ')) || this;
        _this.name = 'ConfigurationError';
        return _this;
    }
    return ConfigurationError;
}(Error));
/**
 * ConfigurationTypeError
 */
var ConfigurationTypeError = /** @class */ (function (_super) {
    __extends(ConfigurationTypeError, _super);
    /**
     * A Custom Error.
     * @param {Message[]} message - The error message
     */
    function ConfigurationTypeError() {
        var message = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            message[_i] = arguments[_i];
        }
        var _this = _super.call(this, message.join(' ')) || this;
        _this.name = 'ConfigurationTypeError';
        return _this;
    }
    return ConfigurationTypeError;
}(TypeError));
var StrictError = /** @class */ (function (_super) {
    __extends(StrictError, _super);
    function StrictError(message, expected, received) {
        var _this = _super.call(this, message) || this;
        _this.name = 'StrictError';
        _this.expected = expected !== null && expected !== void 0 ? expected : '';
        _this.received = received !== null && received !== void 0 ? received : '';
        return _this;
    }
    StrictError.prototype.toString = function () {
        var _a;
        var stack = (_a = this.stack) === null || _a === void 0 ? void 0 : _a.split('\n').slice(2).join('\n');
        var received = this.received ? "".concat(gray('|'), " ").concat(gray(this.received)) : '';
        return "".concat(red(this.name), " > ").concat(yellow(this.message), "\n").concat(red('Expected:'), " ").concat(this.expected, "\n").concat(red('Received:'), " ").concat(this.received, "\n\n").concat(received, "\n\n").concat(gray(stack));
    };
    return StrictError;
}(Error));
function createCustomErrorClass(errorName) {
    return eval("\n    class ".concat(errorName, " extends Error {\n      constructor(message) {\n        const errorMessage = message.join(\"\\n\");\n        super(`").concat(errorName, "\\n${errorMessage}`);\n        this.name = \"").concat(errorName, "\";\n        Object.setPrototypeOf(this, new.target.prototype);\n      }\n    }\n    \n    ").concat(errorName, ";\n  "));
}
function throwError(errorType, errorName) {
    var message = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        message[_i - 2] = arguments[_i];
    }
    if (errorType === 'Custom') {
        var customErrorClass = createCustomErrorClass(errorName);
        throw new customErrorClass(message);
    }
    var errorConstructor = globalThis[errorType] || Error;
    var errorMessage = message.join('\n');
    throw new errorConstructor("".concat(errorName, "\n").concat(errorMessage));
}
exports.throwError = throwError;
var Token = (_a = process === null || process === void 0 ? void 0 : process.env['Token']) !== null && _a !== void 0 ? _a : '';
// ConfiguratonError
if (!Token) {
    var errorMessage = cyan('[ BUG Checker ]') +
        white.bold(' | ') +
        blue("".concat(new Date().toLocaleDateString())) +
        white.bold(' | ') +
        whiteBright("The token isn't provided in .env folder.") +
        white.bold(' | ') +
        yellow.bold('Solution') +
        white(': ') +
        bold.greenBright("Please provide the Token in your environment variables.");
    throwError('Custom', 'ConfigurationError', "".concat(errorMessage));
}
if ((_b = !(process === null || process === void 0 ? void 0 : process.env['MongoDB'])) !== null && _b !== void 0 ? _b : '') {
    var errorMessage = cyan('[ BUG Checker ]') +
        white.bold(' | ') +
        blue("".concat(new Date().toLocaleDateString())) +
        white.bold(' | ') +
        whiteBright("The MongoDB URL isn't provided in .env folder.") +
        white.bold(' | ') +
        yellow.bold('Solution') +
        white(': ') +
        bold.greenBright("Please provide the MongoDB URL in your environment variables.");
    throwError('Custom', 'ConfigurationError', "".concat(errorMessage));
}
if ((_c = !(process === null || process === void 0 ? void 0 : process.env['MongoDB'])) !== null && _c !== void 0 ? _c : ''.includes('mongodb+srv://')) {
    var errorMessage = cyan('[ BUG Checker ]') +
        white.bold(' | ') +
        blue("".concat(new Date().toLocaleDateString())) +
        white.bold(' | ') +
        whiteBright("You've provided an invalid MongoDB Url.") +
        white.bold(' | ') +
        yellow.bold('Solution') +
        white(': ') +
        bold.greenBright("Please check the MongoDB URL in your environment variables.");
    throwError('Custom', 'ConfigurationError', "".concat(errorMessage));
}
if ((_d = !(process === null || process === void 0 ? void 0 : process.env['ClientId'])) !== null && _d !== void 0 ? _d : '') {
    var errorMessage = greenBright('[ BUG Checker ]') +
        white.bold(' | ') +
        blue("".concat(new Date().toLocaleDateString())) +
        white.bold(' | ') +
        whiteBright("Client ID isn't provided in .env file") +
        white.bold(' | ') +
        yellow.bold('Solution') +
        white(': ') +
        bold.cyanBright("Please make sure to add the Client ID to the .env file and restart the bot.");
    throwError('Custom', 'ConfigurationError', "".concat(errorMessage));
}
if ((_e = !(config_1["default"] === null || config_1["default"] === void 0 ? void 0 : config_1["default"].developerIds)) !== null && _e !== void 0 ? _e : '') {
    throw new ConfigurationError("Developer IDs are not provided in the config.js file");
}
// ConfigurationTypeError
if (typeof Token !== 'string') {
    throwError('Custom', 'ConfigurationError', 'Invalid Token', 'was provided.', "\nExpected type of Token to be a valid \"string\" but got ".concat(typeof Token, " instead."));
}
if (typeof (process === null || process === void 0 ? void 0 : process.env['MongoDB']) !== 'string') {
    throw new ConfigurationTypeError('Invalid MongoDB', 'was provided', "\nExpected type of MongoDB to be a valid \"string\" but got ".concat(typeof (process === null || process === void 0 ? void 0 : process.env['MongoDB']), " instead."));
}
if (Array.isArray((_f = config_1["default"] === null || config_1["default"] === void 0 ? void 0 : config_1["default"].developerIds) !== null && _f !== void 0 ? _f : '') &&
    ((_g = config_1["default"] === null || config_1["default"] === void 0 ? void 0 : config_1["default"].developerIds) === null || _g === void 0 ? void 0 : _g.every(function (id) { return typeof id === 'string'; }))) {
    // do nothing, configuration is correct
}
else {
    throw new ConfigurationTypeError("Expected type of developerIds in config.js to be a string array but got ".concat(typeof config_1["default"].developerIds, " instead."));
}
// Strict Checking
loadModule('./index.js');
function loadModule(path) {
    return __awaiter(this, void 0, void 0, function () {
        var resolvedPath, code, lines, isStrictEnabled;
        return __generator(this, function (_a) {
            resolvedPath = require.resolve(path);
            code = fs.readFileSync(resolvedPath, 'utf8');
            lines = code.split('\n');
            isStrictEnabled = lines.some(function (line) { return line.includes('strict'); });
            if (!isStrictEnabled) {
                throw new StrictError("Strict is not enabled in ".concat(resolvedPath), 'strict', 'none');
            }
            return [2 /*return*/];
        });
    });
}
//# sourceMappingURL=checker.js.map