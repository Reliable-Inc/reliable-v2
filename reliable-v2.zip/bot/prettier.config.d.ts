export let endOfLine: string;
export let semi: boolean;
export let singleQuote: boolean;
export let trailingComma: string;
export let arrowParens: string;
export let printWidth: number;
export let tabWidth: number;
export let useTabs: boolean;
export let bracketSpacing: boolean;
export let jsxBracketSameLine: boolean;
export let jsxSingleQuote: boolean;
export let quoteProps: string;
export let proseWrap: string;
export let htmlWhitespaceSensitivity: string;
//# sourceMappingURL=prettier.config.d.ts.map